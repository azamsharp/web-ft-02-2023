const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')
// importing bcryptjs 
var bcrypt = require('bcryptjs');
var session = require('express-session')

// initializing pg promise 
const pgp = require('pg-promise')() 

const connectionString = 'postgres://uspvnjzv:SeB2WxHEUxJuLyue2DYxGuOrlYvCoMdU@peanut.db.elephantsql.com/uspvnjzv'

// use connection string to create the pg-promise object 
// this db object contains a lot of functions to work with the postgres database 
const db = pgp(connectionString)

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')
app.use(express.urlencoded())

// initialize a session 
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true
  }))

// /register 
app.get('/register', (req,res) => {
    res.render('register')
})

// NO REAL USE IN OUR PROJECT. THIS ROUTE IS TO JUST PLAY AROUND WITH bcryptjs and SEE HOW IT WORKS 
app.get('/test', async (req, res) => {

    const password = "password"
    
    let salt = await bcrypt.genSalt(10)
    let hashedPassword = await bcrypt.hash(password, salt)
    res.send(hashedPassword)
    
})

// POST register 
app.post ('/register', async (req, res) => {
    
    const { username, password } = req.body 

    // create the hashed password 
    let salt = await bcrypt.genSalt(10)
    let hashedPassword = await bcrypt.hash(password, salt)

    // insert user into the database 
    await db.none('INSERT INTO users(username, password) VALUES($1, $2)', [username, hashedPassword])
    res.send('GO TO LOGIN SCREEN')
    //res.redirect('/login')

})

// GET login 

app.get('/login', (req, res) => {
    res.render('login')
})

// POST login 
app.post('/login', async (req, res) => {

    const { username, password } = req.body 

    // find the user using their username 
    let user = await db.oneOrNone('SELECT id, username, password FROM users WHERE username = $1', [username])
    if(user) {

        const result = await bcrypt.compare(password, user.password)
        if(result) {
            // user has been authenticated 
            // put something in the session 
            if(req.session) {
                req.session.userId = user.id // OR 
                req.session.username = user.username 
            }
            // send them to dashboard screen
            res.send('GO TO DASHBOARD SCREEN')
        } else {
            // user is NOT authenticated 
            res.render('login', { errorMessage: 'Invalid credentials.'})
        }
    } else {
        res.render('login', { errorMessage: 'Invalid credentials.'})
    }
})

app.get('/dashboard', (req, res) => {

    const username = req.session.username 
    console.log('Hello, ' + username)

    res.render('dashboard', {username: req.session.username})
})

// / 


app.get('/secret', (req, res) => {

    const password = 'password' // THIS PASSWORD NEEDS TO BE HASHED USING Bcryptjs

    res.json({value: 'INSERT HASHED PASSWORD HERE'})

})

app.listen(8080,() => {
    console.log('Server is running...')
}) 