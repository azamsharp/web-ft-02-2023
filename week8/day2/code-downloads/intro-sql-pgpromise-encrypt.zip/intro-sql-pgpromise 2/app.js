const express = require('express')
const app = express()
var session = require('express-session')
// initializing pg promise 
const pgp = require('pg-promise')()
// importing bcryptjs 
var bcrypt = require('bcryptjs');

const mustacheExpress = require('mustache-express')
// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
// the pages are located in views directory
app.set('views', './views')
// extension will be .mustache
app.set('view engine', 'mustache')

app.use(express.urlencoded())

// initialize a session 
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true
  }))

const connectionString = 'postgres://lefsmymq:ZUgT-svwe0hb7m0FVi5Fl6WErGbw0Rfm@chunee.db.elephantsql.com/lefsmymq'

// use connection string to create the pg-promise object 
// this db object contains a lot of functions to work with the poastgres database 
const db = pgp(connectionString)


app.post('/login', (req, res) => {

    const username = req.body.username;
    const password = req.body.password;

    db.one('SELECT user_id, username, password FROM users WHERE username = $1',[username])
    .then((user) => {

        // compare the password 
        bcrypt.compare(password, user.password, function(error, result) {
            if(result) {
                // user has been authenticated 
                if(req.session) {
                    req.session.userId = user.user_id 
                }
                // redirect the user to trips page 
                res.send('TRIPS')
            } else {
                // user is not authenticated 
                // render the login page with message saying user is not authenticated 
                res.send('NOT AUTHENTICATED')
            }
        })

    }).catch((error) => {
        res.send('USER NOT FOUND')
    })

})

app.post('/register', (req, res) => {

    const username = req.body.username 
    const password = req.body.password 

    bcrypt.genSalt(10, function(error, salt) {
        if(!error) {
        bcrypt.hash(password, salt, function(error, hash) {
            if(!error) {
                // insert into the database 
                db.none('INSERT INTO users(username, password) VALUES($1, $2)', [username, hash])
                .then(() => {
                    console.log('User has been inserted')
                    // render the login page 
                    res.send('INSERTED')
                })
            } else {
                res.send('Error occurred!')
            }
        })
    } else {
        res.send('Error occurred!')
    }
    })



   

})


app.listen(3000, () => {
    console.log('Server is running...')
})

