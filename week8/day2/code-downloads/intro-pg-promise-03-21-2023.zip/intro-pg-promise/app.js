const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')
const bcrypt = require('bcryptjs');
const session = require('express-session')

// initializing pg promise 
const pgp = require('pg-promise')()

const connectionString = 'postgres://qnoptaxm:eB1eo6VxMv14qmIlBjkViE-Y_4Bh3VEn@ruby.db.elephantsql.com/qnoptaxm'

// use connection string to create the pg-promise object 
// this db object contains a lot of functions to work with the postgres database 
const db = pgp(connectionString)
console.log(db)

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
// the pages are located in views directory
app.set('views', './views')
// extension will be .mustache
app.set('view engine', 'mustache')
app.use(express.urlencoded())


// initialize a session 
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true
  }))

// login 
app.post('/login', async (req, res) => {

    const username = req.body.username 
    const password = req.body.password // password

    // CRUD 
    // CREATE
    // READ 
    // UPDATE 
    // DELETE 

    let user = await db.oneOrNone('SELECT id, username, password from users WHERE username = $1', [username])

    if(user) {
        // compare passwords 
        const result = await bcrypt.compare(password, user.password)
        if(result) {
            // user has been authenticated 
            // put something in the session 
            if(req.session) {
                req.session.userId = user.id 
            }

            // send them to the home screen 
            res.redirect('/')
        } else {
            res.render('login', { errorMessage: 'Invalid credentials.'})
        }
    } else {
        res.render('login', { errorMessage: 'Invalid credentials.'})
    }

})

// register the user 
app.post('/register', async (req, res) => {

    const username = req.body.username 
    const password = req.body.password 

    // create salt 
    let salt = await bcrypt.genSalt(10)
    let hashedPassword = await bcrypt.hash(password, salt)
    console.log(hashedPassword)
    // create the hashed password 
    
    await db.none('INSERT INTO users(username, password) VALUES($1, $2)', [username, hashedPassword]) 

    // take the user to login screen 
    res.redirect('/') // TODO 
})


app.get('/', async (req, res) => {

    // fetch the movies from the database 
    const movies = await db.any('SELECT name, year FROM movies')
    res.render('index', { movies: movies })
})

app.post('/add-movie', async (req, res) => {
    const movieName = req.body.movieName
    const movieYear = req.body.movieYear

    await db.none('INSERT INTO movies(name, year) VALUES($1, $2)', [movieName, movieYear])

    res.redirect('/')
})

app.listen(8080, () => {
    console.log('Server is running...')
})