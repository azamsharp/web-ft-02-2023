const express = require('express')
const app = express()
require('dotenv').config()
const models = require('./models')
const { Op } = require('sequelize')

const mustacheExpress = require('mustache-express')
// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

app.use(express.urlencoded())

app.get('/movies/:genre', (req, res) => {

    const genre = req.params.genre 

    models.Movie.findAll({
        where: {
            genre: {
                [Op.iLike]: genre 
            }
        }
    }).then(movies => {
        res.render('movies', {movies: movies})
    })

})

// [Sequelize.Op.iLike]: searchQuery

// get movie by id 
app.get('/movies/:movieId', (req, res) => {

    const movieId = req.params.movieId 

    models.Movie.findByPk(movieId)
    .then((movie) => {
        //res.json(movie)
        res.json(movie)
    })

})

app.get('/movies', (req, res) => {

    models.Movie.findAll({})
    .then(movies => {
        res.render('movies', {movies: movies})
    })
})

app.get('/delete-movie/:movieId', (req, res) => {

    const movieId = req.params.movieId 

    models.Movie.destroy({
        where: {
            id: movieId
        }
    }).then(deleteMovie => {
        res.redirect('/movies')
    })

})


app.post('/add-movie', (req, res) => {

    const name = req.body.name
    const genre = req.body.genre 
    const poster = req.body.poster 

    // create the movie object 
    const movie = models.Movie.build({
        name: name, 
        genre: genre, 
        poster: poster 
    })

    // save the movie 
    movie.save().then(savedMovie => {
        console.log(savedMovie)
        res.redirect('/movies')
    })

})

console.log(process.env.SECRET)

app.listen(process.env.PORT,() => {
    console.log('Server is running...')
})