'use strict';

module.exports = {
  // up is fired when you run sequelize db:migrate 
  up: async (queryInterface, Sequelize) => {
    // add new genre column to the movies table 
    return queryInterface.addColumn('Movies', 'genre', {
      type: Sequelize.STRING 
    })
  },

  // down is fired when you run sequelize db:migrate:undo 
  down: async (queryInterface, Sequelize) => {
    // delete the column from the Movies table 
    return queryInterface.removeColumn('Movies', 'genre')
  }
};
