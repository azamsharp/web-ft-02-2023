// ORM - Object Relational Mapper 
// Sequelize - Object Relational Mapper 

const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')
const models = require('./models')
const { Op } = require('sequelize') // Operator 


app.use(express.urlencoded())

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

//let movies = [] 

app.get('/add-movie', (req, res) => {
    res.render('add-movie')
})

app.get('/movies/:movieId', async (req, res) => {

    const movieId = parseInt(req.params.movieId) 
    let movie = await models.Movie.findByPk(movieId)
     // INSTEAD OF res.json, YOU WILL USE res.render AND DISPLAY MOVIES 
    // ON THE SCREEN 
    res.json(movie)

})

app.get('/delete-movie/:movieId', async (req, res) => {
    const movieId = parseInt(req.params.movieId) 

    const deletedMovie = await models.Movie.destroy({
        where: {
            id: movieId
        }
    })
  // INSTEAD OF res.json, YOU WILL USE res.render AND DISPLAY MOVIES 
    // ON THE SCREEN 
    res.json(deletedMovie)
})

app.get('/movies', async (req, res) => {
    let movies = await models.Movie.findAll({})
    res.render('movies', {movies: movies})

    /*
    let movies = await models.Movie.findAll({
        where: {
             genre: {
                [Op.iLike]: genre 
            }
        }
    }) */


    // INSTEAD OF res.json, YOU WILL USE res.render AND DISPLAY MOVIES 
    // ON THE SCREEN 
    //res.json(movies)
}) 


app.post('/add-movie', async (req, res) => {
    const { name, description, year } = req.body 

     // create the movie object 
    const movie = models.Movie.build({
        name: name, 
        description: description, 
        year: parseInt(year)
    })

    // save the movie 
    const _ = await movie.save()
    res.redirect('/movies')
})




app.listen(8080,() => {
    console.log('Server is running...')
})











