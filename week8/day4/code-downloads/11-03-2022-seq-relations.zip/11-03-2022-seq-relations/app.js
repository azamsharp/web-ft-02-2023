const express = require('express')
const app = express()
const models = require('./models')
const session = require('express-session')

require('dotenv').config()

const mustacheExpress = require('mustache-express')
// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

app.use(express.urlencoded())

app.use(session({
    secret: process.env.SESSION_SECRET_KEY,
    saveUninitialized: true
})) 

// / -> index.mustache 
app.get('/', async (req, res) => {

    // get all movies from database using sequelize 
    const movies = await models.Movie.findAll({})
    res.render('index', {movies: movies})
})

app.get('/movies/:movieId', async (req, res) => {

    const movieId = parseInt(req.params.movieId) 
    const movie = await models.Movie.findByPk(movieId, {
        include: [
            {
                model: models.Review, 
                as: 'reviews'
            }
        ]
    })
    console.log(movie)
    res.render('movie-detail', movie.dataValues)

})


app.get('/reviews', async (req, res) => {

    const reviews = await models.Review.findAll({
        include: [
            {
                model: models.Movie, 
                as: 'movie'
            }
        ]
    })
    res.json(reviews)

})


// POST add a review 
app.post('/add-review', async (req, res) => {

    const { title, body, movieId } = req.body 

    const review = models.Review.build({
        title: title, 
        body: body, 
        movie_id: movieId
    })

    let savedReview = await review.save()
    if(savedReview) {
        res.send('SUCCESS')
    } else {
        res.send('FAILED')
    }

})

// POST - add movie 
app.post('/add-movie', async (req, res) => {

    const { name, year, genre } = req.body 

    const movie = models.Movie.build({
        name: name, 
        year: year, 
        genre: genre 
    })

    const savedMovie = await movie.save()
    if(savedMovie) {
        // replace it with res.render 
        res.send('SUCCESS')
    } else {
        // replace it with res.render and show error to the user 
        res.send('NOT ABLE TO CREATE MOVIE')
    }

})


app.listen(process.env.PORT,() => {
    console.log('Server is running...')
}) 