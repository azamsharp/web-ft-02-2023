const express = require('express')
const app = express()

// global so that it is available in all routes 
global.models = require('./models')

const moviesRouter = require('./routes/movies')
const reviewsRouter = require('./routes/reviews')

require('dotenv').config()

const mustacheExpress = require('mustache-express')
// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

app.use(express.urlencoded())

app.use('/movies', moviesRouter)
app.use('/reviews', reviewsRouter)

app.listen(process.env.PORT,() => {
    console.log('Server is running...')
})