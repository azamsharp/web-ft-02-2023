

const express = require('express')
const router = express.Router() 

router.get('/:reviewId', (req, res) => {

    const reviewId = req.params.reviewId 

    models.Review.findByPk(reviewId, {
        include: [
            {
                model: models.Movie, 
                as: 'movie'
            }
        ]
    })
    .then(review => {
        res.json(review)
    })

})

// /reviews/add-review 
router.post('/add-review', (req, res) => {

    const title = req.body.title 
    const body = req.body.body 
    const movieId = parseInt(req.body.movieId) 

    const review = models.Review.build({
        title: title, 
        body: body, 
        movie_id: movieId 
    })

    review.save().then(savedReview => {
        res.send('REVIEW SAVED')
    })

})



module.exports = router 