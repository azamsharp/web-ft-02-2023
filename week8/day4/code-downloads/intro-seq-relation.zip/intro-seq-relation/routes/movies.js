
const express = require('express')
const router = express.Router() 

// /movies
router.get('/', (req, res) => {

    // get all movies and their reviews 
    models.Movie.findAll({
        include: [
            {
                model: models.Review, 
                as: 'reviews'
            }
        ]
    }).then(movies => {
        res.json(movies)
    })

})

// /movies/:movieId 
// /movies/34 

router.get('/:movieId', (req, res) => {

    const movieId = req.params.movieId 

    // get the movie by id and all the reviews of that movie 
    models.Movie.findByPk(movieId, {
        include: [
            {
                model: models.Review, 
                as: 'reviews'
            }
        ]
    }).then(movie => {
        // movie.reviews.map 
        res.json(movie)
    })

})

// /movies/add-movie
router.post('/add-movie', (req, res) => {
    
    const title = req.body.title 
    const rating = parseInt(req.body.rating) 
    const director = req.body.director 
    const genre = req.body.genre 

    const movie = models.Movie.build({
        title: title, 
        rating: rating, 
        director: director, 
        genre: genre 
    })

    movie.save().then(savedMovie => {
        res.send('SAVED')
    })

})

module.exports = router 