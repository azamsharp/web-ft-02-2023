const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')

// initializing pg promise 
const pgp = require('pg-promise')() 

const connectionString = 'postgres://qnoptaxm:eB1eo6VxMv14qmIlBjkViE-Y_4Bh3VEn@ruby.db.elephantsql.com/qnoptaxm'

// use connection string to create the pg-promise object 
// this db object contains a lot of functions to work with the postgres database 
const db = pgp(connectionString)
console.log(db)

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')
app.use(express.urlencoded())

app.post('/delete-movie', async (req, res) => {

    const movieId = parseInt(req.body.movieId) 
    await db.none('DELETE FROM movies WHERE id = $1',[movieId])
    res.redirect('/')
})

// add a new movie 
app.post('/add-movie', async (req, res) => {
    
    const movieName = req.body.movieName 
    const movieYear = parseInt(req.body.movieYear) 

    await db.none('INSERT INTO movies(name, year) VALUES($1,$2)', [movieName, movieYear])

    res.redirect('/')

})

// get all movies and display on the screen 
app.get('/', async (req, res) => {

    // any is used when you want to return an array 
    const movies = await db.any('SELECT id, name, year FROM movies')
    console.log(movies)

    res.render('index', { movies: movies})
})


app.listen(8080,() => {
    console.log('Server is running...')
})