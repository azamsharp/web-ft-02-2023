const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')

// initializing pg promise 
const pgp = require('pg-promise')() 

const connectionString = 'postgres://uspvnjzv:SeB2WxHEUxJuLyue2DYxGuOrlYvCoMdU@peanut.db.elephantsql.com/uspvnjzv'

// use connection string to create the pg-promise object 
// this db object contains a lot of functions to work with the postgres database 
const db = pgp(connectionString)

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')
app.use(express.urlencoded())

// db.any will return you an array of records from the database. It will always return you an array, even if there is a single record 
// db.one will return you a single record from the database. If your query returns multiple records then it will end up in an error 
// db.none will return you nothing from the database. 


// get all movies and display on the screen 
app.get('/', async (req, res) => {

    const movies = await db.any('SELECT movie_id, title, description, is_released FROM movies')
    console.log(movies)
    
    res.render('index', { movies: movies})
})

app.post('/add-movie', async (req, res) => {
    const { title, description, director, released } = req.body 
    
    // save in the database 
    await db.none('INSERT INTO movies(title, description, director, is_released) VALUES($1, $2, $3, $4)',[title, description, director, released == 'on'? true: false]) 

    res.redirect('/')
})

app.post('/delete-movie', async (req, res) => {
    const { movieId } = req.body 

    // delete from the database 
    await db.none('DELETE FROM movies WHERE movie_id = $1', [movieId])

    res.redirect('/')
})

app.get('/add-movie', (req, res) => {
    res.render('add-movie')
})

app.listen(8080,() => {
    console.log('Server is running...')
})