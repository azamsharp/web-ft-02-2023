const express = require('express')
const app = express()

// initializing pg promise 
const pgp = require('pg-promise')() 
//console.log(pgp)

const connectionString = 'postgres://lefsmymq:ZUgT-svwe0hb7m0FVi5Fl6WErGbw0Rfm@chunee.db.elephantsql.com/lefsmymq'

// use connection string to create the pg-promise object 
// this db object contains a lot of functions to work with the postgres database 
const db = pgp(connectionString)

const mustacheExpress = require('mustache-express')
// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

app.use(express.urlencoded())

app.get('/', (req, res) => {

    // get all customers from the database 
    // SELECT first_name, last_name, age, customer_id FROM customers; 
    // any indicates that this query can return any number of rows 
    db.any('SELECT first_name, last_name, age, customer_id FROM customers;')
    .then(customers => {
        res.render('index', {customers: customers})
    })

})

app.get('/customers/:customerId', (req, res) => {

    const customerId = parseInt(req.params.customerId) 

    db.one('SELECT customer_id, first_name, last_name, age FROM customers WHERE customer_id = $1',[customerId]).then(result => {
        // render the page 
        res.json(result)
    })

})

app.post('/add-customer', (req, res) => {

    const firstName = req.body.firstName 
    const lastName = req.body.lastName 
    const age =  parseInt(req.body.age) 

    // INSERT INTO customers(first_name, last_name, age) VALUES('Steven', 'Doe', 56);
    db.none('INSERT INTO customers(first_name, last_name, age) VALUES($1, $2, $3)',[firstName, lastName, age]).then(() => {
        res.redirect('/')
    })
})


app.listen(3000,() => {
    console.log('Server is running...')
})