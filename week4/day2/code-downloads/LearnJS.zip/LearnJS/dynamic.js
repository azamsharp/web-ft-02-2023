
let randomImageButton = document.getElementById('randomImageButton')
randomImageButton.addEventListener('click', function() {

    // create an image element 
    let img = document.createElement('img')
    // add src attribute to the image 
    img.setAttribute('src', 'https://picsum.photos/200/300')
    console.log(img)

    // create a button 
    let btn = document.createElement('button')
    // add event listener to the btn 
    btn.addEventListener('click', function() {
        alert('Thank you!')
    })
    btn.innerHTML = 'Mark as favorite'

    // appendChild is going to add an HTML element to another htML element
    document.body.appendChild(img)
    document.body.appendChild(btn)

})

// <img src = 'https://picsum.photos/200/300' />