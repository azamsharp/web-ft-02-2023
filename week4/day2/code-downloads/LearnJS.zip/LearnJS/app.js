
let helloHeading = document.getElementById('helloHeading')

let firstNameTextBox = document.getElementById('firstNameTextBox')
let lastNameTextBox = document.getElementById('lastNameTextBox')
let showFullNameButton = document.getElementById('showFullNameButton')
showFullNameButton.addEventListener('click', function() {
  helloHeading.innerHTML = `${firstNameTextBox.value}, ${lastNameTextBox.value}`
})




// Access the body element 
// document.body 

// even though you can call buttonClicked on a click of a button, this function is still available to the rest of the app and can be called accidently. 
function buttonClicked() {
  console.log("Button is clicked...")
}



// access an element by its id 
let saveButton = document.getElementById("saveButton")
// click is the name of the event. 
saveButton.addEventListener('click', function() {
    // 
    helloHeading.innerHTML = 'Hello'
})
console.log(saveButton)

let deleteButton = document.getElementById("deleteButton")
console.log(deleteButton) // null 

// get all elements whose tag is li 
console.log(document.getElementsByTagName("li"))




