
let age = 30 
const pi = 3.142 

age = 31 
//pi = 5 // this will throw an error


console.log(this) // Window object 

const taskNameTextBox = document.getElementById('taskNameTextBox')
const addTaskButton = document.getElementById('addTaskButton')
const pendingTaskUL = document.getElementById('pendingTaskUL')

taskNameTextBox.value = 'Hello'

// taskNameTextBox = anything  // error taskNameTextBox is constant 

addTaskButton.addEventListener('click', function() {

    console.log(this) // addTaskButton

    // get access to the value user has typed in the TextBox 
    const taskName = taskNameTextBox.value 
    console.log(taskName)
    // create a li 
    const li = document.createElement('li')
    li.innerHTML = taskName
    // This line will cause an error
    // li = document.createElement('li') // ERROR 

    // create a button 
    const deleteButton = document.createElement('button')
    deleteButton.innerHTML = 'Delete'
    deleteButton.addEventListener('click', function() {
        console.log(this) // delete button 
        console.log(this.parentElement) // li 
        // remove li from ul 
        pendingTaskUL.removeChild(this.parentElement) 
    })

    li.appendChild(deleteButton)

    pendingTaskUL.appendChild(li)


})

/*
  <li>Mow the lawn
            <button>Delete</button>
        </li>
*/
