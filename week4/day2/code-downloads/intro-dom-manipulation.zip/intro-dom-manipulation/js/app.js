
// DOM (Document Object Model) Structure of the HTML Document

// access button using the id 
const btnSubmit = document.getElementById("btnSubmit")
// access textbox using id 
const nameTextBox = document.getElementById("nameTextBox")
// access heading using id <h1>
const nameHeading = document.getElementById("nameHeading")

console.log(btnSubmit)
// attach button event on the button 
// YOU MUST SPELL YOUR EVENTS EXACTLY AS SHOWN BELOW
//btnSubmit.addEventListener("click", buttonClicked)

// attach button event on the button anonymous function 
btnSubmit.addEventListener("click", function() {
    nameHeading.textContent = nameTextBox.value 
})

btnSubmit.addEventListener("mouseover", buttonMouseOver)

console.log(document) 

function buttonMouseOver() {
    console.log("Button mouseoever")
}

function buttonClicked() {

    // get the value of the textbox 
    console.log(nameTextBox.value) 

    // assign the textbox value to the <h1> element 
    nameHeading.textContent = nameTextBox.value 
    
    // the tags/elements between the starting tag and ending tag is known as innerHTML
    //nameHeading.innerHTML = nameTextBox.value 


    console.log("Button has been clicked")
}




 
