

const moviesUL = document.getElementById('moviesUL')

/*
for (let i = 0; i < movies.length; i++) {

  // create an li element 
  const li = document.createElement('li');

  const image = document.createElement('img')
  image.setAttribute('src', movies[i].Poster)

  li.appendChild(image)

  moviesUL.appendChild(li)
  // append li to a ul 

  const titleDiv = document.createElement('div')
  titleDiv.innerHTML = movies[i].Title
  li.appendChild(titleDiv)

  // create i (italic) element 
  const yearI = document.createElement('i')

  // assign the Year property to the italic element innerHTML 
  yearI.innerHTML = movies[i].Year
  li.appendChild(yearI)

} */

// USING TEMPLATE LITERAL 

/*
for(let index = 0; index < movies.length; index++) {
    let movie = movies[index]
    const movieItem = `
    <li>
      <img class = 'poster' src = "${movie.Poster}" />
      <h1>${movie.Title}</h1>
      <i>${movie.Year}</i>
    </li>`
    // concatenating 
    // This will create a brand new string each time movieItem is concatenated 
    // with moviesUL.innerHTML. This can be bad for performance for larger apps 
    //moviesUL.innerHTML += movieItem

    // insertAdjacentHTML will not concatenate the strings 
    // This allows for better performance for larger apps 
    moviesUL.insertAdjacentHTML('beforeend', movieItem)

} */

// TEMPLATE LITERALS WITH AN ARRAY HELPER MAP 

const movieItems = movies.map(function(movie) {
  return ` <li>
  <img class = 'poster' src = "${movie.Poster}" />
  <h1>${movie.Title}</h1>
  <i>${movie.Year}</i>
</li>`
})

moviesUL.innerHTML = movieItems.join('') 






/*
 <li>
        <img src = "" />
        <h1>Batman</h1>
        <i>2023</i>
       </li>
*/

let firstName = "John"
let lastName = "Doe"

// John Doe
let fullName = firstName + " " + lastName


const names = ['Alex', 'Steven', 'John']

console.log(names.join(' and ')) 