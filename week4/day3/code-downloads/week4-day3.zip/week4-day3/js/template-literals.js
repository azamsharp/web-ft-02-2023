
const namesUL = document.getElementById('namesUL')

const names = ["Alex", "John", "Mary", "Steven"]

for(let index = 0; index < names.length; index++) {

    const name = names[index]

    const nameItem = `
        <li>
            <input type = 'radio' name = "radio" />
            <label>${name}</label>
            <button>Remove</button>
        </li>
    `

    // both will do the same thing 
    // namesUL.innerHTML = namesUL.innerHTML + nameItem 
    // compact version 
    // this will create a new string each time the nameItem is concatenated 
    //namesUL.innerHTML += nameItem 

    namesUL.insertAdjacentHTML('beforeend', nameItem)
}

/*
for(let index = 0; index < names.length; index++) {

    const name = names[index]
    // create an li 
    let nameLI = document.createElement('li')
    // create label
    let nameLabel = document.createElement('label')
    nameLabel.innerHTML = name 

    // create checkbox 
    let checkbox = document.createElement('input')
    checkbox.setAttribute('type', 'checkbox')

    // create remove button 
    let removeButton = document.createElement('button')
    removeButton.innerHTML = 'Remove'

    nameLI.appendChild(checkbox)
    nameLI.appendChild(nameLabel)
    nameLI.appendChild(removeButton)

    namesUL.appendChild(nameLI)
} */

