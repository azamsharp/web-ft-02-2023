
const nameTextBox = document.getElementById('nameTextBox')
const submitButton = document.getElementById('submitButton')
const messageHeading = document.getElementById('messageHeading')

submitButton.addEventListener('click', function() {

    const year = 2022 
    const name = nameTextBox.value 
    //const message = 'Hello ' + name + " welcome to " + year + " cohort" // this will create a new string 

    // template literals 
    const message = `Hello ${name}, Welcome to ${year} cohort.`

    messageHeading.innerHTML = message 

})

console.log(nameTextBox)