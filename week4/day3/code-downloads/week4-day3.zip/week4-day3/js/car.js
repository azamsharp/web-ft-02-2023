
const carsUL = document.getElementById('carsUL')

for(let index = 0; index < cars.length; index++) {

    const car = cars[index]
    const carItem = `
        <li>
            <img class = 'photo' src = ${car.photo} />
            <h2>${car.make}</h2>
            <h4>${car.model}</h4>
            <p>${car.color}</p>
            <i>${car.year}</i>
        </li>
    `

    //carsUL.innerHTML += carItem
    carsUL.insertAdjacentHTML('beforeend', carItem)

}

/*
<img src = 'https://images.unsplash.com/photo-1494905998402-395d579af36f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2670&q=80' />
*/
