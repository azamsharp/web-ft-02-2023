

// # is for get by id 
// . get by class name 
const stockSymbolTextBox = document.querySelector("#stockSymbolTextBox")
const btnSubmitQuote = document.querySelector("#btnSubmitQuote")
const quoteHeading = document.querySelector("#quoteHeading")

stockSymbolTextBox.setCustomValidity("Enter this!")

const stockQuoteForm = document.getElementById("stockQuoteForm")

stockQuoteForm.addEventListener("submit", (event) => {

    console.log(stockQuoteForm.checkValidity()) 

    const symbol = stockSymbolTextBox.value 
    populateQuotes(symbol)

    window.setInterval(function() {
        populateQuotes(symbol)
    }, 2000)

    event.preventDefault()
})

/*
btnSubmitQuote.addEventListener("click", () => {

    console.log(stockQuoteForm.checkValidity()) 

    const symbol = stockSymbolTextBox.value 
    populateQuotes(symbol)

    window.setInterval(function() {
        populateQuotes(symbol)
    }, 2000)

}) */

function populateQuotes(symbol) {
    const quote = getStockQuote(symbol)
    console.log(quote)
    quoteHeading.innerHTML = `${quote.name} - $${quote.price}` 
}

