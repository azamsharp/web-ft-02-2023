

//window.setInterval(Function to call, time in milliseconds)
const counterHeading = document.getElementById('counterHeading')

let counter = 0 

// setInterval is called repeatedly unless cancelled 
/*
const intervalId = window.setInterval(function() {
    counter++
    counterHeading.innerHTML = counter
}, 1000) // 5000 = 5 seconds
*/

// stop or terminate the interval
//window.clearInterval(intervalId)

// setTimeout is called once 
//window.setTimeout(incrementCounter, 5000)

/*
function incrementCounter() {
    console.log('incrementCounter was called')
} */



function getNewCounterValue(callback) { // reference to the displayCounter function 
   
    let counter = 0 

    window.setInterval(function() {
        counter++ // increment the counter 
        callback(counter) // call the callback function // displayCounter 
        // return the counter 
    }, 2000) 

    //return counter 
}

//getNewCounterValue(displayCounter) // displayCounter is a function 

getNewCounterValue(function(ctr) {
    console.log(ctr)
})

/*
function displayCounter(ctr) {
    console.log(ctr)
} */

//displayCounter(100)


const fullName = "John"

function displayName(personName) {
    console.log(personName)
}

displayName(fullName)

let quote = getStockQuote('FB')
console.log(quote)




