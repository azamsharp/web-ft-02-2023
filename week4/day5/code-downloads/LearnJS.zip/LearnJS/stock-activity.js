
console.log(this) // window 

const stockPriceHeading = document.getElementById('stockPriceHeading')


function fetchStockQuote(fetchStockQuoteCallback) {
    
    window.setInterval(function() {
        let quote = getStockQuote('FB')
        fetchStockQuoteCallback(quote)
        console.log(quote)
        // how do we display it on the screen 
        stockPriceHeading.innerHTML = quote.price
    }, 2000)

}


fetchStockQuote(function(quote) {
    sendEmail(quote)
}) 


// I need to email the quote ???



function sendEmail(quote) {
    // email it 
}
