
// h1 element 
// CALLBACK FUNCTIONS 
// A callback function is a function passed to another function that will be called sometime later 


const stockQuoteHeading = document.getElementById("stockQuoteHeading")

//const stockSymbolTextBox = document.getElementById("stockSymbolTextBox")

// the code below should be inside a button click 
// inside the button click you will get the value 
// of the textbox 
window.setInterval(function() {
    // get the value from the textbox 
    const result = getStockQuote('GOOG')
    stockQuoteHeading.innerText = `$${result.price}`
    console.log(result)

}, 2000)

let user = {name: "John Doe", hobby: "Movies"}

user.name 
user.hobby 

user["name"] // John Doe
user["hobby"] // Movies 

