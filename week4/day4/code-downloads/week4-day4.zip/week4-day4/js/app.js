
// get access to dishesUL 
const dishesUL = document.getElementById("dishesUL")
// get access to starters button 
const startersButton = document.getElementById('startersButton')
startersButton.addEventListener('click', function() {

    // filter function returns true/false 
    // if filter returns true then that item is added to the final array otherwise it is not 
    const filteredDishes = dishes.filter(function(dish) {
        return dish.course == "Starters" //&& dish.price > 10 
    })

    console.log(filteredDishes)

    const dishItems = filteredDishes.map(function(dish) {
        return  `<li class = 'dish-item'>
                     <img src = ${dish.imageURL} />
                    <h1>${dish.title}</h1>
                     <h3>${dish.description}</h3>
                  </li>
            `
    }) 
    
    dishesUL.innerHTML = dishItems.join("")

})

const dishItems = dishes.map(function(dish) {
    return  `<li class = 'dish-item'>
                 <img src = ${dish.imageURL} />
                <h1>${dish.title}</h1>
                 <h3>${dish.description}</h3>
              </li>
        `
})

console.log(dishItems)

dishesUL.innerHTML = dishItems.join("")


/*
for (let index = 0; index < dishes.length; index++) {

    const dish = dishes[index]

    // create the dishLI using template literals 

    const dishItem =
        `<li class = 'dish-item'>
               <img src = ${dish.imageURL} />
               <h1>${dish.title}</h1>
               <h3>${dish.description}</h3>
         </li>
        `

    // add dishItem to dishesUL 
    dishesUL.insertAdjacentHTML('beforeend', dishItem)
} */

// ARRAY HELPERS (map, reduce, filter, find, some)

const numbers = [1,2,3,4,5,6,7,8]
let doubleNumbers = [] 

for(let index = 0; index < numbers.length; index++) {
    const number = numbers[index]
    const result = number * 2 
    doubleNumbers.push(result)
}

console.log(doubleNumbers)

// map = transformation function = it works on an array and returns a BRAND NEW ARRAY. map never changes the original array. It always returns a brand new array 

let result = numbers.map(function(n) {
    // whatever you return from the map function 
    // is added to the final array 
    return n * 2 
})

console.log(result)


