
const dishesUL = document.getElementById('dishesUL')
const entreesButton = document.getElementById('entreesButton')
const dessertsButton = document.getElementById('dessertsButton')

entreesButton.addEventListener('click', () => {
    const entrees = getDishesByCourse('Entrees')
    displayDishes(entrees)
})

dessertsButton.addEventListener('click', () => {
   const desserts = getDishesByCourse('Desserts')
   displayDishes(desserts)
})

function getDishesByCourse(course) {

    // SAME 
    return dishes.filter(dish => dish.course == course)

    /* SAME 
    return dishes.filter((dish) => {
        return dish.course == course
    }) */
}

function displayDishes(dishesToDisplay) {
    const dishItems = dishesToDisplay.map((dish) => {
        return `
        <li>
            <img src = '${dish.imageURL}' class = 'dish-photo' />
            <b>${dish.title}</b>
            <p>${dish.description}</p>
        </li>
        `
    })
    
    dishesUL.innerHTML = dishItems.join('')
}

displayDishes(dishes) 

