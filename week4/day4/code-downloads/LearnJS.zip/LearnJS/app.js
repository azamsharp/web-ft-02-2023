
const counterHeading = document.getElementById('counterHeading')

const quoteTextBox = document.getElementById('quoteTextBox')
const showQuoteButton = document.getElementById('showQuoteButton')
const quoteNameHeading = document.getElementById('quoteNameHeading')
const quotePriceHeading = document.getElementById('quotePriceHeading')

let intervalId = 0

showQuoteButton.addEventListener('click', () => {

  // cancel the interval 
  window.clearInterval(intervalId)

  // get the value from the TextBox 
  const symbol = quoteTextBox.value

  intervalId = window.setInterval(function () {
    // call getStockQuote and get quote for a stock 
    const quote = getStockQuote(symbol)

    // display quote name and price on the screen 
    quoteNameHeading.innerHTML = quote.name
    quotePriceHeading.innerHTML = `$${quote.price}`
  }, 2000)

})




/*
function greet() {
  console.log('HELLO!')
} */

// setTimeout 
// milliseconds 5000 milli = 5 seconds 
// setTimeout is called only once and then it is cancelled
/*
window.setTimeout(function() {
  console.log('HELLO!')
}, 5000)
*/

//greet() 

// setInterval 
// setInterval is called repeatedly 
let counter = 3 // this value should come from TextBox  
/*
let intervalId = window.setInterval(function() {
  if(counter < 0) {
    window.clearInterval(intervalId)
    document.body.style.backgroundColor = 'green'
  } else {
    counterHeading.innerHTML = counter
  }
  counter-- 
 
}, 1000)
*/



