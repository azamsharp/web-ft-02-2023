

let quote = getStockQuote("APLE")
console.log(quote)