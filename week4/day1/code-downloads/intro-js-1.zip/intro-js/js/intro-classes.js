
// There are NO classes in JavaScript 

function Car(make, model) {
    this.make = make 
    this.model = model 
    this.vin = ''
    this.speed = 0.0 
}

function drive() {
    console.log('DRIVE')
}

function brake() {
    console.log('BRAKE')
}

//drive() 
//brake() 

// drive() // We are not planning to call drive like this

// properties attached using prototypes will be 
// available in all new Car objects 
Car.prototype.drive = function() {
    console.log('DRIVE')
    this.speed += 10 
} 

Car.prototype.brake = brake 

// anonymous functions don't have a name 
Car.prototype.changeGear = function(gear) {
    console.log("CHANGE GEAR " + gear)
}

// car = Car('Honda', 'Accord') // Python
let car = new Car('Honda', 'Accord')

console.log(car)

car.drive() 
car.brake() 
car.changeGear(3) 

let anotherCar = new Car('Toyota', 'Camry')
anotherCar.drive() 
anotherCar.brake() 

console.log(car.__proto__)

car.fillUp = function() {
    console.log('FILL UP')
}

car.fillUp() 

// Accessing properties of anotherCar 
console.log(anotherCar.model)
console.log(anotherCar.make)

console.log(anotherCar['make'])
console.log(anotherCar['model'])

let emptyObject = {}
emptyObject.firstName = 'John'
emptyObject.lastName = 'Doe'
console.log(emptyObject)

// MODERN CLASS SYNTAX 

class ElectricCar {
    constructor(make, model, range) {
        this.make = make 
        this.model = model 
        this.range = range 
        this.speed = 0 
    }

    drive() {
        this.speed += 10 
    }

    brake() {

    }
}

let electricCar = new ElectricCar('Tesla', 'Model X', 300)
electricCar.drive() 
electricCar.brake() 

