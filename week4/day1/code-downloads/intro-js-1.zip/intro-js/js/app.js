
console.log("Hello World")

let age = 45 // USE let 
var name = "John" // var is kind of like let but with different scope 
age = 56 // This is fine because age is declared as a let variable 

const pi = 3.142 
// pi = 4 // This will result in an error

// JavaScript uses camel casing 
let isPublished = true 

// ARRAYS 
let friends = ["Alex", "Mary", "Steven"]
console.log(friends)

// LOOPS 
// for(starting value, condition, how you increment the index)
for(let index = 0; index < friends.length; index++) {
    //console.log(index)
    console.log(friends[index])
}

// FUNCTIONS 

sayHello() // function hoisting 

function sayHello() {
    console.log("Say Hello!")
}

sayHello() 

function displayName(name) {
    console.log(name)
}

displayName("Mary Doe")

function add(a, b) {
    return a+b 
}

let result = add(4,5) // result will be 9 

let tasks = [] // empty array 

tasks.push('Wash car')
tasks.push('Feed dog')
tasks.push("Trim Leaves")
tasks.push("Mail envelope")
tasks.push("Take a walk")
tasks.push(100)

console.log(tasks)

// deleting item from an array 
let deletedItem = tasks.pop() // removes the last item from the array
console.log(tasks)

// deleting item based on an index 
delete tasks[1]
console.log(tasks)

// deleting range of items 
tasks.splice(0, 3) // (starting index, number of items to delete)
console.log(tasks)

// WHILE LOOP 

let counter = 0 
while(counter <= 10) {
    
    if(counter % 2 == 0) {
        break 
    }
}

// CONDITIONS  
let version = 3 
let os = 'Windows'

if(version == 3) {
    console.log('version is 3')
} else if(version == 2) {
    console.log('version is 2')
} else {
    console.log('Some other version')
}

// AND 
if(version == 1 && os == 'windows' && 1 == 1) {

}
// OR 
if(version == 2 || os == 'windows') {
    
}