import logo from './logo.svg';
import './App.css';
import Counter from './Counter';
import DisplayCounter from './DisplayCounter';

function App() {
  return (
   <div>
     <Counter />
     <DisplayCounter />
   </div>
  );
}

export default App;
