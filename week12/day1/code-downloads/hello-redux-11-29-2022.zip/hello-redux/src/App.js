import DecrementCounter from "./components/DecrementCounter";
import DisplayCounter from "./components/DisplayCounter";
import IncrementCounter from "./components/IncrementCounter";
import { useEffect } from 'react'
import { connect } from 'react-redux'
import PostList from "./components/PostList";

function App(props) {

  useEffect(() => {

    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(posts => {
      // put the posts in global state 
      props.onPostsLoaded(posts)
    })

  },[])

  return (
      <>
        <DisplayCounter />
        <IncrementCounter />
        <DecrementCounter />
        <PostList />
      </>
  );
}

const mapDispatchToProps = (dispatch) => {

  return {
    onPostsLoaded: (posts) => dispatch({type: 'SAVE_POSTS', payload: posts})
  }

}


export default connect(null,mapDispatchToProps)(App);
