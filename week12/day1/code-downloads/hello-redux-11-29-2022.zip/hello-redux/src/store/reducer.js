
import * as actionTypes from './actions/actionTypes'

const initialState = {
    count: 99, 
    posts: [] 
}

const reducer = (state = initialState, action) => {

    switch(action.type) {
        case actionTypes.INCREMENT: 
            return {
                ...state, 
                count: state.count + 1 
            }
        case actionTypes.DECREMENT: 
            return {
                ...state, 
                count: state.count - 1 
            }
        case actionTypes.ADD: 
            return {
                ...state, 
                count: state.count + action.payload 
            }
        case 'SAVE_POSTS': 
            return {
                ...state, 
                posts: action.payload 
            }
        default: 
            return state 
    }
}

export default reducer 