
import { connect } from 'react-redux'

function PostList(props) {

    const postItems = props.posts.map((post) => {
        return <li key = {post.id}>{post.title}</li>
    })

    return (
        <ul>
            {postItems}
        </ul>
    )
}

const mapStateToProps = (state) => {
    return {
        posts: state.posts 
    }
}

export default connect(mapStateToProps)(PostList)