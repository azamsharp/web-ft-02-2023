
import { connect } from 'react-redux'
import * as actionTypes from '../store/actions/actionTypes'

function DecrementCounter(props) {

    return (
        <button onClick = {props.onDecrement}>Decrement</button>
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onDecrement: () => dispatch({type: actionTypes.DECREMENT})
    }
}

export default connect(null, mapDispatchToProps)(DecrementCounter)