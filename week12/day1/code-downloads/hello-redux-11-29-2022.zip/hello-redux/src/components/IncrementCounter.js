
import { connect } from 'react-redux'
import { useState } from 'react'
import * as actionCreators from '../store/creators/actionCreators'

function IncrementCounter(props) {

    const [inputValue, setInputValue] = useState(0)

    const handleChange = (e) => {

        const value = e.target.value 
        if(value.length == 0) {
            return 
        }  

        setInputValue(parseInt(value))
    }

    return (
        <>
        <button onClick = {props.onIncrement}>Increment</button>
        <input type = 'text' onChange = {handleChange} />
        <button onClick = {() => props.onAdd(inputValue)}>Add</button>
        </>
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onAdd: (value) => dispatch(actionCreators.addCounter(value)),
        onIncrement: () => dispatch(actionCreators.incrementCounter())
    }
}

export default connect(null, mapDispatchToProps)(IncrementCounter)