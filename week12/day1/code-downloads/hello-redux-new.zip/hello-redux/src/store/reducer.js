
const initialState = {
    counter: 299, 
    name: 'John Doe', 
    isAuthenticated: false, 
    tasks: [] 
}

const reducer = (state = initialState, action) => {

    if(action.type == 'INCREMENT') {
        return {
            ...state, 
            counter: state.counter + 1 
        }
    } else if(action.type == 'ADD') {
        return {
            ...state, 
            counter: state.counter + action.payload 
        }
    } else if(action.type == 'ON_UPDATE_COUNTER') {
        return {
            ...state, 
            counter: state.counter + action.payload
        }
    }

    return state 
}

export default reducer 