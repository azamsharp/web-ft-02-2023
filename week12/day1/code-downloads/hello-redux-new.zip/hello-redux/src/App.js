
import './App.css';
import { connect } from 'react-redux'
import Counter from './components/Counter';

function App(props) {

  const handleIncrement = () => {
    props.onIncrement()
  }

  const handleAdd = () => {
    props.onAdd() 
  }

  return (
   <div>
     <h1>{props.ctr}</h1>
     <button onClick = {handleIncrement}>Increment</button>
     <button onClick = {handleAdd}>ADD 10</button>
    <Counter />
   </div>
  );
}

// mapStateToProps allows you to read the global state and make it available as properties in your components 

const mapStateToProps = (state) => {
  return {
    ctr: state.counter 
  }
}


const mapDispatchToProps = (dispatch) => {
  return {
    onIncrement: () => dispatch({type: 'INCREMENT'}), 
    onAdd: () => dispatch({type: 'ADD', payload: 10})
  }
} 

/*
const mapDispatchToProps = function(dispatch) {
  return {
    onIncrement: function() { dispatch({type: 'INCREMENT'}) }
  }
}*/

export default connect(mapStateToProps, mapDispatchToProps)(App) 


