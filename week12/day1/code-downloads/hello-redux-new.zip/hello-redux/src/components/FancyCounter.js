
import { connect } from 'react-redux'
import { useState } from 'react'

function FancyCounter(props) {

    const [counter, setCounter] = useState('')

    const handleOnChange = (e) => {
        const count = e.target.value
        setCounter(count)
    }

    const handleUpdateCounter = () => {
        props.onUpdateCounter(parseInt(counter))
        setCounter('')
    }

    return (
        <div>
            <h1>FancyCounter</h1>
            <input type = "text" value = {counter} onChange = {handleOnChange} />
            <button onClick = {handleUpdateCounter}>Update Counter</button>
        </div>
       
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onUpdateCounter: (value) => dispatch({type: 'ON_UPDATE_COUNTER', payload: value})
    }
}

export default connect(null, mapDispatchToProps)(FancyCounter)