
import { connect } from 'react-redux'
import FancyCounter from './FancyCounter'
import { useState } from 'react'

function Counter(props) {
    return (
        <div>
            <h1>Counter</h1>
            {props.ctr}
            {props.name}
            <FancyCounter />
        </div>
       
    )
}

const mapStateToProps = (state) => {
    return {
        ctr: state.counter, 
        name: state.name  
    }
}

export default connect(mapStateToProps)(Counter) 