
import { useState } from 'react'
import { connect } from 'react-redux'

function FancyCounter(props) {

    const [counter, setCounter] = useState('')

    const handleChange = (e) => {
        setCounter(e.target.value)
    }

    const handleAdd = () => {
        props.onAdd(parseInt(counter))
    }

    return (
        <>
         <h1>FancyCounter</h1>
         <input type = "text" onChange = {handleChange} />
         <button onClick = {handleAdd}>Add</button>
        </>
       
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onAdd: (value) => dispatch({type: 'ADD', payload: value})
    }
}

export default connect(null, mapDispatchToProps)(FancyCounter) 