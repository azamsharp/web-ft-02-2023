
import { connect } from 'react-redux'
import FancyCounter from './components/FancyCounter';

function App(props) {

  const handleIncrement = () => {
    props.onIncrement() 
  }

  return (
      <>
      <h1>{props.ctr}</h1>
      <button onClick = {handleIncrement}>Increment</button>
      <FancyCounter />
      </>
  );
}

// mapStateToProps allows you to read the global state and make it available as properties in your components 

const mapStateToProps = (state) => {
  return {
    ctr: state.count
  }
}

// mapDispatchToProps allows the dispatching to be accessible through the user of local properties 
const mapDispatchToProps = (dispatch) => {
  return {
    onIncrement: () => dispatch({type: 'INCREMENT'})
  }
}


// if your component is not dispatching/updating the global state
// export default connect(mapStateToProps)(App);

// if your component is not displaying the values from global state
// export default connect(null, mapDispatchToProps)(App);

// if your component is displaying values from global state and dispathing/updating global state 
export default connect(mapStateToProps, mapDispatchToProps)(App);
