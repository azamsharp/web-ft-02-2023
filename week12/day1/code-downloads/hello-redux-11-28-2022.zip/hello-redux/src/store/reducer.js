
// reducer is a function that takes two arguments. 
// state = current global state 
// action = action sent by the component after dispatching 

// global state 
const initialState = {
    count: 99, 
    isAuthenticated: false, 
    books: ['Book 1']   
}

const reducer = (state = initialState, action) => {
    
    if(action.type === 'INCREMENT') {
        return {
            // spread operator and it copies the properties and values from one object to the other object
            ...state, 
            count: state.count + 1 
        }
    } else if(action.type == 'ADD') {
        return {
            ...state, 
            count: state.count + action.payload 
        }
    }

    return state 
}

export default reducer 


