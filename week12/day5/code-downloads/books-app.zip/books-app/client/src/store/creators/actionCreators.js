

export const fetchBooks = () => {

    return (dispatch) => {
        fetch('http://localhost:8080/api/books')
        .then(response => response.json())
        .then(books => {
            dispatch({type: 'BOOKS_LOADED', payload: books})
        })
    }
}

// npm install redux-thunk