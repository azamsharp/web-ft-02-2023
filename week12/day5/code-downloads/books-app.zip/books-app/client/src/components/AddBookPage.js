
import { useState } from 'react'
import { connect } from 'react-redux'
import * as actionCreators from '../store/creators/actionCreators'

function AddBookPage(props) {

    const [book, setBook] = useState({})

    const handleBookChange = (e) => {
        //console.log(e.target.name, e.target.value)

        setBook({
            ...book,
            [e.target.name]: e.target.value 
        })
    }

    const handleBookSave = () => {

        //console.log(JSON.stringify(book))

        fetch('http://localhost:8080/api/books', {
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json'
            }, 
            body: JSON.stringify(book) 
        }).then(response => response.json())
        .then(result => {
            props.onBooksLoaded()
        })
    }

    return (
        <div>
            <h1>Add Book Page</h1>
            <input name = "title" onChange = {handleBookChange} type = "text" placeholder = "title" />
            <input name = "isbn" onChange = {handleBookChange} type = "text" placeholder = "isbn" />
            <input name = "publisher" onChange = {handleBookChange} type = "text" placeholder = "publisher" />
            <button onClick = {handleBookSave}>Save</button>
        </div>
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
      onBooksLoaded: () => dispatch(actionCreators.fetchBooks())
    }
  }

export default connect(null, mapDispatchToProps)(AddBookPage) 