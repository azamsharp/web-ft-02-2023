
import { useEffect, useState } from 'react'
import AddBookPage from './AddBookPage'
import { connect } from 'react-redux'
import * as actionCreators from '../store/creators/actionCreators'

function BookListPage(props) {

   //const [count, setCounter] = useState(0)

    useEffect(() => {
      props.onBooksLoaded()
    }, [])

    const handleBookDelete = (book) => {
        fetch(`http://localhost:8080/api/books/${book.id}`, {
          method: 'DELETE'
        }).then(response => response.json())
        .then(result => { 
          props.onBooksLoaded()
        })
        
    }

    const bookItems = props.books.map(book => {
      return <li key = {book.id}>
          <b>{book.title}</b>
          <button onClick = {() => handleBookDelete(book)}>Delete</button>
        </li>
    })

    return (
      <ul>
        {bookItems}
        <AddBookPage />
      </ul>
    )
}

const mapDispatchToProps = (dispatch) => {
  return {
    onBooksLoaded: () => dispatch(actionCreators.fetchBooks())
  }
}

const mapStateToProps = (state) => {
  return {
    books: state.books 
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(BookListPage);
