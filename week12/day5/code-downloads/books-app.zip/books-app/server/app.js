
const express = require('express')
const models = require('./models')
const cors = require('cors')
const db = require('./models')
const app = express() 

app.use(express.json())
app.use(cors())

// // initializing pg promise 
/*
const pgp = require('pg-promise')() 

const connectionString = 'postgres://hbavaivu:kYRhxMNzNT-Ja7OdQgZBsZOsP-2ImAn2@chunee.db.elephantsql.com/hbavaivu'

const db = pgp(connectionString) 
app.get('/api/books-with-pg-promise', (req, res) => {

    db.any('SELECT id, title, isbn, publisher FROM "Books";')
    .then(books => {
        console.log(books)
    })

}) */


app.get('/hello', (req, res) => {
    res.send('Hello')
})

app.post('/api/books', (req, res) => {

    const title = req.body.title
    const isbn = req.body.isbn 
    const publisher = req.body.publisher 

    const book = models.Book.build({
        title: title, 
        isbn: isbn, 
        publisher: publisher 
    })

    // save a book 
    book.save()
    .then(savedBook => {
        res.json({success: true, bookId: savedBook.id})
    })

})

app.get('/api/books', (req, res) => {
    // get all books
    models.Book.findAll({})
    .then(books => {
        res.json(books)
    })
})

app.delete('/api/books/:bookId', (req, res) => {

    const bookId = parseInt(req.params.bookId) 

    models.Book.destroy({
        where: {
            id: bookId
        }
    }).then(_ => {
        res.json({success: true})
    })

})

// db.none('DELETE FROM "Books" WHERE id = $0',[bookId])


app.listen(8080, (req, res) => {
    console.log('Server is running...')
})