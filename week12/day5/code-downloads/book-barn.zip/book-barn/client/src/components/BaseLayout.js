const { default: Menu } = require("./Menu");

function BaseLayout(props) {
    return (
        <>
            <Menu />
            {props.children}
        </>
    )
}

export default BaseLayout