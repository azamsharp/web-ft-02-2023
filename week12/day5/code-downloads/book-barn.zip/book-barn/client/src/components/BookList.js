
// http://localhost:8080/api/books
import { useEffect, useState } from 'react'

function BookList() {

    const [books, setBooks] = useState([])

    const fetchBooks = () => {
        fetch('http://localhost:8080/api/books')
        .then(response => response.json())
        .then(books => {
            setBooks(books)
        })
    }

    useEffect(() => {
        fetchBooks() 
    },[])

    const bookItems = books.map(book => {
        return <li key = {book.id}>{book.name}</li>
    })

    return (
        <ul>
            {bookItems}
        </ul>
    )
}

export default BookList 
