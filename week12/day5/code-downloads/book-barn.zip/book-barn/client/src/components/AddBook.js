
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function AddBook() {

    const navigate = useNavigate() 
    const [book, setBook] = useState({})

    const handleChange = (e) => {
        setBook({
            ...book,
            [e.target.name]: e.target.value
        })
    }

    const handleSubmit = (e) => {

        e.preventDefault() 
        // check if the textboxes are empty. 
        // if they are empty then don't make the post request 

        fetch('http://localhost:8080/api/books', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                bookName: book.name,
                bookIsbn: book.isbn,
                bookGenre: book.genre
            })
        }).then(response => response.json())
        .then(result => {
            // check the result if the book was added or not 
            navigate('/')
        })

    }

    return (
        <>
            <h1>AddBook</h1>
            <form onSubmit={handleSubmit}>
                <input type='text' name='name' placeholder='enter book name' onChange={handleChange} required />
                <input type='text' name='isbn' placeholder='enter book isbn' onChange={handleChange} />
                <input type='text' name='genre' placeholder='enter book genre' onChange={handleChange} />
                <button>Add Book</button>
            </form>
        </>
    )
}

export default AddBook