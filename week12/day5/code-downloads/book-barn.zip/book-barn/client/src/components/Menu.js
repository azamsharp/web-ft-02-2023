
import { NavLink } from 'react-router-dom'

function Menu() {
    return (
        <div>
            <NavLink to = "/">Home</NavLink>
            <NavLink to = "/add-book">Add Book</NavLink>
        </div>
    )
}

export default Menu 