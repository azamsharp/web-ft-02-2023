
const express = require('express')
const app = express()
const cors = require('cors')
app.use(cors())

app.use(express.json())

const models = require('./models')

app.get('/api/books', async (req, res) => {
    const books = await models.Book.findAll({})
    res.json(books)
})

// add a book using POST 
app.post('/api/books', async (req, res) => {
   
   const { bookName, bookIsbn, bookGenre } = req.body
    
   // check to make sure that all properties have a value 
   if(!bookName || !bookIsbn || !bookGenre) {
        res.json({success: false, message: 'Invalid request'})
        return 
   }

   const book = models.Book.build({
    name: bookName, 
    isbn: bookIsbn, 
    genre: bookGenre
   })

   const savedBook = await book.save()
   if(savedBook) {
        res.json({success: true, message: 'Book has been saved.'})
   } else {
        res.json({success: false, message: 'Book not saved.'})
   }

})

app.listen(8080,()=>{
    console.log('Books server is running...')
})