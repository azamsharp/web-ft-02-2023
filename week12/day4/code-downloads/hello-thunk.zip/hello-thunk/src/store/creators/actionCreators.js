
import * as actionTypes from '../actions/actionTypes'


export const loadProducts = () => {

    return (dispatch) => {

        fetch('https://api.escuelajs.co/api/v1/products?offset=0&limit=10')
            .then(response => response.json())
            .then(products => {
                // MIDDLEWARE (redux-thunk) WILL ALLOW IS ACCESS TO dispatch INSIDE 
                // ACTION CREATOR 
                dispatch({type: actionTypes.PRODUCTS_LOADED, payload: products})
            })

    }

}