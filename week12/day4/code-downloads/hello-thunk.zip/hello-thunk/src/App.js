
import { useEffect } from 'react'
import { connect } from 'react-redux'
import * as actionCreators from './store/creators/actionCreators'

function App(props) {

  useEffect(() => {
    props.onLoadProducts()
  },[])

  /*
  const fetchProducts = () => {
    fetch('https://api.escuelajs.co/api/v1/products?offset=0&limit=10')
    .then(response => response.json())
    .then(products => {
        props.onProductsLoaded()
    })
  } */

  const productItems = props.products.map((product) => {
    return <li key = {product.id}>{product.title}</li>
  })

  return (
      <>
        <h1>Products</h1>
        <ul>
          {productItems}
        </ul>
      </>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {                          
    onLoadProducts: () => dispatch(actionCreators.loadProducts())
  }
}

const mapStateToProps = (state) => {
  return {
    products: state.products
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
