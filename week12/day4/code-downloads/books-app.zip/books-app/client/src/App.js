
import { useEffect } from 'react'
import { connect } from 'react-redux'
import BookList from './components/BookList'
import * as actionCreators from './store/creators/actionCreators'

function App(props) {

  useEffect(() => {
    props.onFetchBooks()
  }, [])

  return (
      <div>
        <h1>App</h1>
        <BookList />
      </div>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    onFetchBooks: () => dispatch(actionCreators.fetchBooks()) 
  }
}

export default connect(null, mapDispatchToProps)(App);
