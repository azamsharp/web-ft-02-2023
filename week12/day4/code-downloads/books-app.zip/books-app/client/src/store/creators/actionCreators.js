

// {type: 'BOOKS_LOADED', payload: books}


export const addCounter = (value) => {
    return {
        type: 'ADD', 
        payload: value 
    }
}

export const fetchBooks = () => {

    return (dispatch) => {
        // fetch the books from the server 
        fetch('http://localhost:8080/books')
            .then(response => response.json())
            .then(books => {
                // dispatch an action to give the books to the reducer and the reducer will update the global state
            dispatch({type: 'BOOKS_LOADED', payload: books})
            })
    }
}