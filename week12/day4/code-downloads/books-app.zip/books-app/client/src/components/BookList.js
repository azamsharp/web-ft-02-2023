
import { connect } from 'react-redux'

function BookList(props) {

    const bookItems = props.books.map((book) => {
        return <li>{book.title} - {book.isbn}</li>
    })

    return (
        <div>
            <h1>Books</h1>
            {bookItems}
        </div>
    )

}

const mapStateToProps = (state) => {
    return {
        books: state.books
    }
}

export default connect(mapStateToProps)(BookList)