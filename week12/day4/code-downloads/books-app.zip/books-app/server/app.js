
const express = require('express')
const cors = require('cors')
const app = express() 

app.use(cors())

let books = [
    {title: 'Book 1', isbn: 'wsedrf'}, 
    {title: 'Book 2', isbn: '1234'}
]
// http://localhost:8080/books
app.get('/books', (req, res) => {
    res.json(books)
})


app.listen(8080, () => {
    console.log('Server is running...')
})