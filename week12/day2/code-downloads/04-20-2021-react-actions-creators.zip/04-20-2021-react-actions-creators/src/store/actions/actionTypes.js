

export const TASK_ADD = 'TASK_ADD'
export const INCREMENT = 'INCREMENT'
export const MOVIES_LOADED = 'MOVIES_LOADED'
