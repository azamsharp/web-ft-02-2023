

export const POSTS_LOADED = 'POSTS_LOADED'
export const INCREMENT = 'INCREMENT'