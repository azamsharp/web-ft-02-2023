
import * as actionTypes from '../actions/actionTypes'

export const incrementCounter = (value) => {
    return {
        type: actionTypes.INCREMENT, 
        payload: value 
    }
}

export const savePosts = (posts) => {
    return {
        type: actionTypes.POSTS_LOADED, 
        payload: posts 
    }
}