
import './App.css';
import { connect } from 'react-redux'
import { useEffect } from 'react'
import PostList from './components/PostList';
import * as actionCreators from './store/creators/actionCreators'
import Counter from './components/Counter';


function App(props) {
  
  useEffect(() => {

    // fetch data from json placeholder 
    // https://jsonplaceholder.typicode.com/posts
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(posts => {
      console.log(posts)
      props.onPostsLoaded(posts)
    })

  },[])

  return (
   <div>
      <h1>App</h1>
      <Counter />
      <PostList />
   </div>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    onPostsLoaded: (posts) => dispatch(actionCreators.savePosts(posts))
  }
}

export default connect(null, mapDispatchToProps)(App)

