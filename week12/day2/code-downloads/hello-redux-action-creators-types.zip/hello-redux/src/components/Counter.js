
import { connect } from 'react-redux'
import * as actionCreators from '../store/creators/actionCreators'

function Counter(props) {

    return (
        <div>
            <h1>Counter</h1>
            <h4>{props.ctr}</h4>
            <button onClick = {() => props.onIncrement(3)}>Increment</button>
        </div>
    )
}

const mapStateToProps = (state) => {
    return {
        ctr: state.counter 
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onIncrement: (value) => dispatch(actionCreators.incrementCounter(value))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Counter)

