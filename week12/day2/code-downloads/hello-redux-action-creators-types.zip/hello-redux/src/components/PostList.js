
import { connect } from 'react-redux'

function PostList(props) {

    const postItems = props.posts.map((post) => {
        return <li key = {post.id}>{post.title}</li>
    })

    return (
        <div>
            <h1>PostList</h1>
            <ul>
                {postItems}
            </ul>
        </div>
    )
}

const mapStateToProps = (state) => {
    return {
        posts: state.posts
    }
}

export default connect(mapStateToProps)(PostList)