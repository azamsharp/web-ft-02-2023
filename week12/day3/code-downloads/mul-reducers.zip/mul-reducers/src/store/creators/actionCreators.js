

import * as actionTypes from '../actions/actionTypes'

export const saveTask = (task) => {
    return {
        type: actionTypes.TASK_ADD, 
        payload: task
    }
}