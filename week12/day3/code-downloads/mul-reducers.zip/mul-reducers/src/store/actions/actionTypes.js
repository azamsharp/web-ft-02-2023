

export const INCREMENT = 'INCREMENT'
export const DECREMENT = 'DECREMENT'
export const TASK_ADD = 'TASK_ADD'