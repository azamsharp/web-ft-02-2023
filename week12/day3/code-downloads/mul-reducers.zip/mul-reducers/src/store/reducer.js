

// reducer.js has been divided into counter and tasks reducers and this file is now NOT BEING USED 
import * as actionTypes from '../store/actions/actionTypes'

const initialState = {
    counter: 99, 
    tasks: ['Wash car', 'Feed dog'], 
    isAuthenticated: false, 
    randomImages: []  
}

const reducer = (state = initialState, action) => {
    switch(action.type) {
        case actionTypes.INCREMENT: 
            return {
                ...state, 
                counter: state.counter + 1 
            }
        case actionTypes.DECREMENT: 
            return {
                ...state, 
                counter: state.counter - 1 
            }
        
        case actionTypes.TASK_ADD: 
            return {
                ...state, 
                tasks: state.tasks.concat(action.payload)
            }
        
        case 'ADD_RANDOM_IMAGE': 
            return {
                ...state, 
                randomImages: state.randomImages.concat(action.payload)
            }
        
        default: 
            return state 
    }
}

export default reducer 