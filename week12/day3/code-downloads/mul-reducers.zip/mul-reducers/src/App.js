import Counter from "./components/Counter";
import RandomImage from "./components/RandomImage";
import TodoList from "./components/TodoList";

function App() {
  return (
    <div>
        <Counter />
        <TodoList />
        
        {/*<RandomImage />*/}
    </div>
  );
}

export default App;
