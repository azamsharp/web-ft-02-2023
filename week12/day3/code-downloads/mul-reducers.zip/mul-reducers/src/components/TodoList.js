
import { useState } from 'react'
import { connect } from 'react-redux'

import * as actionCreators from '../store/creators/actionCreators'

function TodoList(props) {

    const [taskName, setTaskName] = useState('')

    const handleTaskNameChange = (e) => {
        setTaskName(e.target.value)
    }

    const handleSave = () => {
        props.onTaskAdd(taskName)
    }

    const taskItems = props.tasks.map((task, index) => {
        return <li key = {index}>{task}</li>
    })

    return (
        <div>
            <h1>TodoList</h1>
            <input type = "text" placeholder = "Task name" onChange = {handleTaskNameChange} />
            <button onClick = {handleSave}>Save</button>
            <button onClick = {() => props.onTaskAdd(taskName)}>Save Task</button>
            {taskItems}
        </div>
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onTaskAdd: (task) => dispatch(actionCreators.saveTask(task))
    }
}

const mapStateToProps = (state) => {
    return {
        tasks: state.taskRed.tasks 
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TodoList) 