
import { connect } from 'react-redux'

function RandomImage(props) {

    const handleGenerateRandomImage = () => {
        const randomURL = `https://picsum.photos/200/300?time=${new Date().getTime()}`
        console.log(randomURL)
        props.onAddRandomImage(randomURL)
    }

    const randomImageItems = props.images.map(imageUrl => {
        return <img src = {imageUrl} />
    })

    return (
        <div>
            <h1>RandomImage</h1>
            <button onClick = {handleGenerateRandomImage}>Generate Random Image</button>
            {randomImageItems}
        </div>
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onAddRandomImage: (url) => dispatch({type: 'ADD_RANDOM_IMAGE', payload: url})
    }
}

const mapStateToProps = (state) => {
    return {
        images: state.randomImages 
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(RandomImage) 