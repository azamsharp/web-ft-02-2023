
import { connect } from 'react-redux'
import * as actionTypes from '../store/actions/actionTypes' 

function Counter(props) {
    
    /*
    const taskItems = props.tasks.map((task) => {
        return <li>{task}</li>
    }) */ 

    return (
        <div>
            <button onClick = {props.onIncrement}>Increment</button>
            <h1>{props.ctr}</h1>
            <button onClick = {props.onDecrement}>Decrement</button>
        </div>
    )
}

// Allows you to access global redux state using your local props 
const mapStateToProps = (state) => {
    return {
        ctr: state.counterRed.counter
        //tasks: state.tasks 
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onIncrement: () => dispatch({type: actionTypes.INCREMENT}), 
        onDecrement: () => dispatch({type: actionTypes.DECREMENT})
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Counter) 