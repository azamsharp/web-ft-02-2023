import {connect} from 'react-redux'
import {useState} from 'react'

function TodoList(props) {
    
   const [task, setTask] = useState({})

    const handleChange = (e) => {

        if(e.target.name == "taskPriority") {
            if(e.target.value == "Select priority") {
                alert('Please make sure to select correct priority')
                return 
            }
        }

       setTask({
        ...task,
        [e.target.name]: e.target.value
       })
   }

   const taskItems = props.tasks.map(task => {
        return <li>{task.taskName} - {task.taskPriority}</li>
   })
    
    return (
        <>
            <input type= "text" name = "taskName" onChange ={handleChange}/>
            <select name = "taskPriority" onChange = {handleChange}>
                <option>Select priority</option>
                <option>High</option>
                <option>Medium</option>
                <option>Low</option>
            </select>
            <button type ='text' onClick = {() => props.onTaskAdd(task)}>Add Task</button>

            {taskItems}

            Inside TodoList Component: {props.ctr}
        </>
    )
}

const mapStateToProps = (state) => {
    return {
        ctr: state.counterRed.count,
        tasks: state.tasksRed.tasks 
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onTaskAdd: (task) => dispatch({type: 'TASK_ADD', payload: task})
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TodoList)