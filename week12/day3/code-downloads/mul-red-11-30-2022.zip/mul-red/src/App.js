import {connect} from 'react-redux'
import TodoList from './components/TodoList'
import { v4 as uuidv4 } from 'uuid';

function App(props) {

  const randomImageItems = props.randomImages.map(ri => {
    return <img src = {ri} />
  })

  return(
      <>
        <h1>{props.ctr}</h1>
        <button onClick={props.onIncrement}>Increment</button>
        <button onClick={props.onDecrement}>Decrement</button>

       <TodoList />

        <button onClick = {() => props.onRandomImageAdd(`https://picsum.photos/200/300?uuid=${uuidv4()}`)}>Add Random Image</button>

      {randomImageItems}

      </>
)

}

const mapStateToProps = (state) => {
  return {
    randomImages: state.randomImagesRed.randomImages,
    ctr: state.counterRed.count
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onRandomImageAdd: (url) => dispatch({type: 'ADD_RANDOM_IMAGE', payload: url}),
    onIncrement: () => dispatch({type: 'INCREMENT'}),
    onDecrement: () => dispatch({type: 'DECREMENT'})
   }
}


export default connect(mapStateToProps, mapDispatchToProps)(App);


