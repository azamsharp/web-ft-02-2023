
const moviesUL = document.getElementById('moviesUL')

function getAllMovies(moviesFetchedCallback) {

    // create async request 
    let request = new XMLHttpRequest() 
    // attach load event listener which is fired when the response is received 
    request.addEventListener('load', function() {
        const result = JSON.parse(this.responseText)
        console.log(result)
        let movies = result.Search 
        moviesFetchedCallback(movies) // calling the callback function
    })
    
    request.open('GET','https://www.omdbapi.com/?s=Batman&page=2&apiKey=564727fa')
    request.send() 
}

getAllMovies(function(allMovies) {
    displayMovies(allMovies)
}) 

/*
getAllMovies(function(allMovies) {
    displayMoviesOniPhone(allMovies) 
}) */

function displayMovies(movies) {
    
    const movieItems = movies.map(function(movie) {
        return `<li>
                    <b>${movie.Title}</b>
                    <img src = ${movie.Poster} />
        </li>`
    })

    moviesUL.innerHTML = movieItems.join('')
}



