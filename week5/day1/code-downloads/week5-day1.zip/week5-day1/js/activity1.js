
// https://island-bramble.glitch.me/dog-facts

let req = new XMLHttpRequest() 

req.addEventListener('load', function() {
    console.log(this.responseText)
    const dogFacts = JSON.parse(this.responseText)
    console.log(dogFacts)

    const dogFactItems = dogFacts.map((function(dogFact) {
        return `<li>${dogFact.fact}</li>`
    }))

    //dogFactsUL.innerHTML = dogFactItems.join('')
})

req.open('GET', 'https://island-bramble.glitch.me/dog-facts')
req.send() 