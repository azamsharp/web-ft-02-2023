
const moviesUL = document.getElementById('moviesUL')

let request = new XMLHttpRequest() // async request 

request.addEventListener('load', function() {
    console.log(this)
    // JSON.parse takes in a valid JSON string and returns an object
    const result = JSON.parse(this.responseText)
    const movies = result.Search 
    // display movies on the screen 
    const movieItems = movies.map(movie => {
        return `<li>${movie.Title}</li>`
    })

    moviesUL.innerHTML = movieItems.join('')
})

request.open('GET', 'https://www.omdbapi.com/?s=Batman&page=2&apiKey=564727fa')
request.send()