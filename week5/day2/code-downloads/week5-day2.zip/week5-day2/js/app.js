
const moviesUL = document.getElementById('moviesUL')
const movieTitleHeading = document.getElementById('movieTitleHeading')
const movieDirectorHeading = document.getElementById('movieDirectorHeading')

function showDetails(imdbID) {

    const url = `http://www.omdbapi.com/?i=${imdbID}&apikey=564727fa`
    let request = new XMLHttpRequest()
    request.addEventListener('load', function() {
        const result = JSON.parse(this.responseText)
        movieTitleHeading.innerHTML = result.Title 
        movieDirectorHeading.innerHTML = result.Director 
    })
    request.open('GET', url)
    request.send() 
}

function getMovies() {

    const url = 'http://www.omdbapi.com/?s=Batman&page=2&apikey=564727fa'
    let request = new XMLHttpRequest() 
    request.addEventListener('load', function() {
        const result = JSON.parse(this.responseText)
        const movies = result.Search
        
        const movieItems = movies.map(function(movie) {
            return `<li>
                <a class = "movie-title-link" href = "#" onclick = "showDetails('${movie.imdbID}')">${movie.Title}</a>
            </li>`
        })

        img.setAttribute('src', result.message)
        moviesUL.innerHTML = movieItems.join('')
    })
    request.open('GET', url)
    request.send() 

}

getMovies() 


