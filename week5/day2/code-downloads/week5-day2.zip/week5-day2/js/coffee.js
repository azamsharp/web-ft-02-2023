// https://troubled-peaceful-hell.glitch.me/orders

const emailTextBox = document.getElementById('emailTextBox')
const typeTextBox = document.getElementById('typeTextBox')
const placeOrderButton = document.getElementById('placeOrderButton')

placeOrderButton.addEventListener('click', function() {

    const url = 'https://troubled-peaceful-hell.glitch.me/orders'

    let request = new XMLHttpRequest()
    request.addEventListener('load', function() {
        const result = JSON.parse(this.responseText)
        if(result.success) {
            alert(result.message)
        }
    })
    request.open('POST', url)
    // telling the server the request is of type json 
    request.setRequestHeader('Content-Type', 'application/json')

    const body = {
        email: emailTextBox.value, 
        type: typeTextBox.value, 
        size: 'Medium', 
        price: 4.50 
    }

    console.log(body)
    console.log(JSON.stringify(body))
    request.send(JSON.stringify(body)) 
})
