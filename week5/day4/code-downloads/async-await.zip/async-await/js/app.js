// This is app.js 

const a = 10 
