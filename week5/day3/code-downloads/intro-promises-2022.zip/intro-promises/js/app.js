const placeOrderButton = document.getElementById('placeOrderButton')

placeOrderButton.addEventListener('click', function(){
    
    // https://troubled-peaceful-hell.glitch.me/orders

    const url = 'https://troubled-peaceful-hell.glitch.me/orders'

    let request = new XMLHttpRequest()
    request.open('POST', url)
    request.setRequestHeader('Content-Type', 'application/json')
  
    request.addEventListener('load', function() {
        let result = JSON.parse(this.responseText)
        if(result.success) {
            alert(result.message)
        } else {
            alert('Unable to place an')
        }
    })

    const body = {
        email: "marydoe@gmail.com", 
        type: "Hot Coffee 2", 
        size: "Small", 
        price: 4 
    }

    request.send(JSON.stringify(body)) 
})



