

// CREATE A PROMISE 

let somePromise = new Promise(function(resolve, reject) {
    resolve() // promise has been fulfilled 
    //reject() // promise has been rejected 
})

// XMLHTTPREQUEST 

/*
let request = new XMLHttpRequest()
request.addEventListener('load', function() {
    const result = JSON.parse(this.responseText)
    console.log(result)
})
request.open('GET', 'https://endurable-bead-polo.glitch.me/stocks')
request.send() 
*/

// FETCH API (Fetch API uses Promises) 

const placeOrderButton = document.getElementById('placeOrderButton')
placeOrderButton.addEventListener('click', function() {
    const order = {
        email: "steven@gmail.com", 
        type: "Hot Coffee", 
        size: "Small", 
        price: 6
    }   
    placeOrder(order) 
})

async function placeOrder(order) {
    const response = await fetch('https://troubled-peaceful-hell.glitch.me/orders', {
        method: 'POST', 
        headers: {
            'Content-Type': 'application/json'
        }, 
        body: JSON.stringify(order)
    })
    const result = await response.json()
    console.log(result)
}


/*
placeOrderButton.addEventListener('click', function() {
    
    // POST a new coffee order 
    const body = {
        email: "steven@gmail.com", 
        type: "Hot Coffee", 
        size: "Small", 
        price: 6
    }   

    fetch('https://troubled-peaceful-hell.glitch.me/orders', {
        method: 'POST', 
        headers: {
            'Content-Type': 'application/json'
        }, 
        body: JSON.stringify(body)
    }).then(response => {
        return response.json()
    }).then(result => {
        console.log(result)
    })

}) */




// the default http method for fetch is GET 
fetch('https://endurable-bead-polo.glitch.me/stocks')
.then(response => {
    return response.json()
}).then(result => {
    displayStocks(result)
}).catch(error => {
    console.log(error)
})

function displayStocks(stocks) {
    // stocks.map.... 
    // create template literals 
    // assign to the UL 
}

async function getStocks()  {

    try {
        let response = await fetch('https://endurable-bead-polo.glitch.me/stocks')
        let stocks = await response.json()
        console.log(stocks)
    } catch {
        print(error)
    }

}

getStocks() 



