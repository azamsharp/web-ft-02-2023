
// https://troubled-peaceful-hell.glitch.me/orders

function getAllOrders(ordersDownloaded) {
    fetch('https://troubled-peaceful-hell.glitch.me/orders')
        .then(response => {
            return response.json()
        }).then(orders => {
            ordersDownloaded(orders)
        })
}

function displayOrders(orders) {

    const orderItems = orders.map(function (order) {
        return `<li>
            <label>${order.email}</label>
            <label>${order.type}</label>
        </li>`
    })

    ordersUL.innerHTML = orderItems.join("")
}

getAllOrders(function(orders) {
    displayOrders(orders)
})