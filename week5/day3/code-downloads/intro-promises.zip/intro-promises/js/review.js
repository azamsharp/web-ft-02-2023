
const ordersUL = document.getElementById('ordersUL')
const GET_ALL_ORDERS_URL = 'https://troubled-peaceful-hell.glitch.me/orders'


function getAllOrders(ordersFetched) {

    const request = new XMLHttpRequest() 
    request.open('GET', GET_ALL_ORDERS_URL)
    request.addEventListener('load', function() {
        orders = JSON.parse(this.responseText)
        ordersFetched(orders)
    })
    
    request.send()
}

getAllOrders(function(orders) {
    //console.log(orders)
    displayOrders(orders)
}) 

function displayOrders(orders) {

    const orderItems = orders.map(function(order) {
        return `<li>
            <label>${order.email}</label>
            <label>${order.type}</label>
        </li>`
    })

    ordersUL.innerHTML = orderItems.join("")
}




