

// CREATE A PROMISE 
/*
let promise = new Promise(function(resolve, reject) {
    resolve(100) // promise has been fulfilled 
    //reject() // promise has been rejected 
})

// chaining of different promises 
promise.then(function(number) {
    console.log(number)
    console.log('promise has been resolved')
    return 'hello'
}).then(function(word) {
    console.log(word)
})
.catch(function(error) {
    console.log('promise has been rejected')
}) */


/*
const request = new XMLHttpRequest() 
    request.open('GET', GET_ALL_ORDERS_URL)
    request.addEventListener('load', function() {
        orders = JSON.parse(this.responseText)
    })
    request.send()
*/

const GET_ALL_POSTS_URL = 'https://jsonplaceholder.typicode.com/posts'


function getAllPosts(postsDownloaded) {    

    fetch(GET_ALL_POSTS_URL)
        .then(response => {
            return response.json()
        }).then(result => {
            // call the callback function 
            postsDownloaded(result)
        }).catch((error) => {
            console.log(error)
        })
}

getAllPosts((posts) => {
    console.log(posts)
})

fetch(GET_ALL_POSTS_URL)
.then(response => {
    return response.json()
}).then((posts) => {
    console.log(posts)
})


fetch(GET_ALL_POSTS_URL)
    .then(function (response) {
        return response.json()
    }).then(function (result) {
        console.log(result)
    })

