const express = require('express')
const app = express() 
const mustacheExpress = require('mustache-express')

app.use(express.urlencoded()) // This is so express can parse your body 

// setting up mustache as a templating engine 
app.engine('mustache', mustacheExpress())
// the pages are located in the views directory
app.set('views', './views')
// extension for all the pages 
app.set('view engine', 'mustache')

let tasks = [
    {taskId: 1, title: 'Wash the car', priority: 'high'}, 
    {taskId: 2, title: 'Feed the dog', priority: 'medium'}
] 

app.post('/delete-task', (req, res) => {
    
    const taskId = parseInt(req.body.taskId)

    tasks = tasks.filter((task) => {
        return task.taskId != taskId
    })

    res.redirect('/tasks')
})

app.get('/api/tasks', (req, res) => {
    res.json(tasks)
})

app.post('/add-task', (req, res) => {

    const taskName = req.body.taskName 
    const taskPriority = req.body.taskPriority

    console.log(taskName, taskPriority)

    const task = { title: taskName, priority: taskPriority }

    tasks.push(task)

    res.render('add-task', {allTasks: tasks})

    // TODO 
    // call the action/route /tasks and do whatever is done in that action 
    //res.render('tasks',{ allTasks: tasks })


    //res.redirect('/tasks')
})

app.get('/add-task', (req, res) => {
    res.render('add-task', { allTasks: tasks })
})

app.get('/tasks', (req, res) => {
    res.render('tasks',{ allTasks: tasks })
})

app.get('/', (req,res) => {
    let fullName = 'John Doe'
    res.render('index', { name: fullName, age: 45 })
})

app.listen(3000, () => {
    console.log('Server is running...')
})