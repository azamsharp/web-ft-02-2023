

// Accessing HTML elements is NOT GOING TO WORK 
//document.getElementById('foo') // NOT GOING TO WORK BECAUSE THIS IS NOT CLIENT THIS IS SERVER

let todos = [] 

const express = require('express')
const app = express() 

// body parser middleware 
// This allows express to parse/read json body 
app.use(express.json())

// localhost:8080 GET 
// Return: "Hello World"

app.get('/hello', (req, res) => {
    res.send("Hello World")
})

// localhost:8080/greetings/:name 
// Return: "Hello, John" where John is the value dynamic parameter called :name

// /greetings/mary 
// /greetings/alex
// /greetings/123
// /greetings/lego   
app.get('/greetings/:name', (req, res) => {

})

// /movies/year/2020 
// 1950 - 2020

// /movies/year/1950 

app.get('/movies/year/:year', (req, res) => {
    const year = req.params.year
    res.json(year)
})

app.get('/todos', (req, res) => {
    res.json(todos)
})

app.post('/todos', (req, res) => {
    const title = req.body.title
    const priority = req.body.priority 
    const todo = { id: todos.length + 1, title: title, priority: priority }
    todos.push(todo)
    res.json({message: 'Todo item has been inserted.'})
})

app.delete('/todos/:taskId', (req, res) => {
    const taskId = parseInt(req.params.taskId) 
    // 1. remove the task from the array based on the task id 
    

    res.json({message: 'Task has been removed!'})
})

app.listen(8080, () => {
    console.log('Server is running...')
})

// NOT CONNECTED TO OUR NODE/EXPRESS CODE ABOVE 
/*
const tasks = [{id: 1, title: 'Mow lawn'}, {id: 2, title: 'Clean car'}]
const idToDelete = 2 

// delete or remove the task whose id is idToDelete (2)
// HINTS: splice/filter
*/


