// SERVER SIDE PAGES IN NODE EXPRESS 


const express = require('express')
const app = express() 
const mustacheExpress = require('mustache-express')

// This is so express can parse your body 
app.use(express.urlencoded()) 

// TEMPLATE ENGINE 
// Pug, HandleBars, Mustache 

let movies = [{title: 'Batman', year: 2022}, {title: 'Spiderman', year: 2021}, {title: 'Superman', year: 2019}]

// setting up mustache as a templating engine 
app.engine('mustache', mustacheExpress())
// the pages are located in the views directory
app.set('views', './views')
// extension for all the pages 
app.set('view engine', 'mustache')

// index route/ root route 
app.get('/', (req, res) => {
    res.render('index') // render a page/view called index.mustache 
})

// /featured-movie
app.get('/featured-movie', (req, res) => {
    res.render('featured', { name: 'Spiderman', year: 2022})
})

// /movies 
app.get('/movies', (req, res) => {
    // res.render(name of the mustache page, data as an object)
    res.render('movies', { allMovies: movies})
})

// movies/add-movie 
// method: POST 
app.post('/movies/add-movie', (req, res) => {
    
    let movie = {title: req.body.movieName, year: req.body.movieYear}
    // add movie to the movies array  
    movies.push(movie)
    // render a page to show all movies 
    res.render('movies', {allMovies: movies})
})

app.listen(8080, () => {
    console.log('Server is running...')
})