const express = require('express')
const mustacheExpress = require('mustache-express')
const session = require('express-session')
const tripsRouter = require('./routes/trips')
const authenticate = require('./authentication/authenticateMiddleware')

const app = express()
// http is already part of the Node 
const http = require('http').Server(app)
// initialize socket.io object 
const io = require('socket.io')(http)

app.use('/js',express.static('js'))

let users = [
    {username: 'johndoe', password: 'password'}, 
    {username: 'marydoe', password: 'password'}
]

// middleware 
app.use(express.urlencoded())
// middleware 
app.use(express.static('public'))

// middleware for session 
app.use(session({
    secret: 'THISISSECRETKEY', 
    saveUninitialized: false, 
    resave: true 
}))

app.use('/trips', authenticate,  tripsRouter)

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

app.get('/login', (req, res) => {
    res.render('login')
})


app.get('/chat', (req, res) => {
    console.log(__dirname) // path to the project folder 
    res.sendFile(__dirname + '/chat.html')
})

let chatMessages = [] 

io.on('connection', (socket) => {

    console.log('User connected...')
    //io.emit('Houston', chatMessages)

    socket.on('Houston', (chat) => {
        //chatMessages.push(chat)
        io.emit('Houston', chat)
    })

})

// /trips
// /trips/add-trip 
// /trips/delete-trip

/* moved to trips.js 
app.get('/trips',authenticate, (req, res) => {
    res.render('trips')
}) */

/* moved to trips.js 
app.get('/add-trip',authenticate, (req, res) => {
    res.render('add-trip')
}) */

app.post('/login', (req, res) => {
    
    const username = req.body.username
    const password = req.body.password 

    const persistedUser = users.find(user => {
        return user.username == username && user.password == password
    })

    if(persistedUser) { 
        // if the user is in the array and username and password is matching 
        if(req.session) {
            req.session.username = persistedUser.username 
        }

        res.redirect('/trips')

    } else {
        res.render('login', {errorMessage: 'Username or password is incorrect!'})
    }
})

app.get('/logout', (req, res) => {
    req.session.destroy(error => {
        res.clearCookie('connect.sid')
        res.redirect('/login')
    })
})


http.listen(3000,() => {
    console.log('Server is running...')
})