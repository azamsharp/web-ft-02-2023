
const greetButton = document.getElementById("greetButton")
const messageHeading = document.getElementById("messageHeading")

greetButton.addEventListener('click', () => {

    fetch('http://localhost:3000/api/greet')
    .then(response => response.json())
    .then(result => {
        messageHeading.innerHTML = result.message 
    })

})