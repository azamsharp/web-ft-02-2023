
const express = require('express')
const router = express.Router() 


// trips 
router.get('/', (req, res) => {
    res.render('trips')
})

// /trips/add-trip
router.get('/add-trip', (req, res) => {
    res.render('add-trip')
})

module.exports = router 