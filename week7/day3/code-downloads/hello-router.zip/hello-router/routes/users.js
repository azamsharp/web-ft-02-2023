
// /users 
// /users/:userId 
// /users/*

const express = require('express')
const router = express.Router()

// /users 
router.get('/', (req, res) => {
    res.send('Users')
})

// /users/24
router.get('/:userId', (req, res) => {
    res.send('User with Id')
})

// now other files can import router 
module.exports = router 

