const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')
const usersRouter = require('./routes/users')
const tripsRouter = require('./routes/trips')


app.use(express.urlencoded())
app.use('/css/version-1', express.static('public'))
app.use(express.static('public'))

// everything inside the public folder is available at the root level 
// localhost:3000/css/styles.css

// register the router 
// /users GET 
// /users/34 GET
// /users/add-user POST
// /users/update-user POST 
app.use('/users', usersRouter)
app.use('/trips', tripsRouter)


// localhost:3000/js/client.js
//app.use(express.static('public'))
// href="/css/version-1/site.css"

// localhost:3000/site.css 


// trips are now available in all router files 
global.trips = [
    { name: "Denver", tripId: 1 },
    { name: "Houston", tripId: 2 },
    { name: "Austin", tripId: 3 }
]

const PORT = 3000

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
// the pages are located in views directory
app.set('views', './views')
// extension will be .mustache
app.set('view engine', 'mustache')


app.get('/', (req, res) => {
    res.render('index', {trips: trips})
})



app.listen(PORT, () => {
    console.log('Server is running...')
})