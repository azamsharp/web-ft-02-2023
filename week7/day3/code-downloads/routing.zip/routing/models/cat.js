

class Cat {
    constructor() {
        this.name = ""
    }
}

module.exports = Cat 

