
const express = require('express')
const router = express.Router()

// localhost:8080/trips 
router.get('/', (req, res) => {
    res.render('index', { trips: trips})
})

/*
router.get('/:city', (req, res) => {
    const city = req.params.city
    res.render('index', { city: city })
}) */

// localhost:8080/trips/add-trip 
router.get ('/add-trip', (req,res) => {
    res.render('add-trip')
})

// localhost:8080/trips/delete-trip 
router.post('/delete-trip', (req, res) => {

    const tripId = parseInt(req.body.tripId) 
    // delete the trip from the trips array based on the tripId
    // give me all the trips from the trips array but not the trip whose Id I am providing you. 
    trips = trips.filter(trip => trip.id != tripId)

    // display all the trips 
    res.redirect('/trips')
})

// localhost:8080/trips/add-trip 
router.post('/add-trip', (req, res) => {
    const tripName = req.body.tripName 
    let trip = { id: trips.length + 1, name: tripName }
    trips.push(trip)
    // redirect me or take me to that route 
    res.redirect("/trips")
})

 // now other files can import router 
module.exports = router 