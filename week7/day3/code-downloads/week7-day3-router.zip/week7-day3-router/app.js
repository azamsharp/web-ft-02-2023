const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')
// IMPORTING router from trips.js
const tripsRouter = require('./routes/trips')
//const usersRouter = require('./routes/users')

// Everything in the public folder is available at the root level 
// Everything in the public folder is available at the root level 
// Everything in the public folder is available at the root level 
// Everything in the public folder is available at the root level 
// Everything in the public folder is available at the root level 
app.use(express.static('public'))

// localhost:8080/image1.jpg

app.use(express.urlencoded())

// all the routes which contains trips are handled by tripsRouter 
// localhost:8080/trips 
// localhost:8080/trips/add-trip
// localhost:8080/trips/delete-trip
// localhost:8080/trips/update-trip  
// localhost:8080/trips/a/b/c/d
app.use('/trips', tripsRouter)

//app.use('/users', usersRouter)

app.get('/', (req, res) => {
    res.render('index')
})

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
// the pages are located in views directory
app.set('views', './views')
// extension will be .mustache
app.set('view engine', 'mustache')

// trips are now available in all router files 
global.trips = [{ id: 1, name: 'Denver'}, {id: 2, name: 'Houston'}, {id: 3,name: 'Portland'}]

app.listen(8080, () => {
    console.log('Server is running...')
})