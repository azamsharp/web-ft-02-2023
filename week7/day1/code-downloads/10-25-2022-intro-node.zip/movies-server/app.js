
let movies = [
    {name: 'Spiderman', genre: 'Action'}, 
    {name: 'Batman', genre: 'Action'}, 
    {name: 'Finding Nemo', genre: 'Kids'},
    {name: 'Lego Movie', genre: 'Kids'}
]

let todos = [
    {title: 'Mow the lawn', priority: 'high'}
]

// import express 
const express = require('express')
const cors = require('cors')
const app = express()

// use cors as a middleware.. middleware is discussed later 
app.use(cors())   
// tell the server how to parse JSON body 
app.use(express.json()) 

// create an endpoint to return all movies 
// /movies 
app.get('/movies', (req, res) => {
    res.json(movies)
})

// POST ADD NEW MOVIE 
// req.body is the body being sent by the client 
app.post('/movies', (req, res) => {
    console.log("HELLO")
    //const movie = req.body 
    const movie = { name: req.body.name, genre: req.body.genre }
    movies.push(movie)
    res.json({message: 'New movie has been added!'})
})

// ROUTE PARAMETERS / DYNAMIC ROUTES 
// /movies/:genre     // :genre can be called anything 
// matches: 
// /movies/action 
// /movies/kids 
// /movies/horror 
// /movies/abc 
app.get('/movies/:genre', (req, res) => {
    const genre = req.params.genre

    const filteredMovies = movies.filter(movie => {
        return movie.genre.toLocaleLowerCase() == genre.toLocaleLowerCase()
    })
    res.json(filteredMovies)
})

// /movies/:genre/:year
// /movies/action/2022
// /movies/kids/2021
// /movies/a/b
// /movies/1/2
app.get('/movies/:genre/:year', (req, res) => {
    const genre = req.params.genre
    const year = req.params.year 
    res.send(`The genre is ${genre} and the year is ${year}`)
}) 

// /movies/year/:movieYear






// return movies based on genre 
// /movies/action 
/*
app.get('/movies/action', (req, res) => {
    const actionMovies = movies.filter(movie => movie.genre == 'Action')
    res.json(actionMovies)
})

// return movies based on genre 
// /movies/kids  
app.get('/movies/kids', (req, res) => {
    const kidsMovies = movies.filter(movie => movie.genre == 'Kids')
    res.json(kidsMovies)
}) */


// http://localhost:8080/
// function(request from the client, response from the server)
/*
app.get('/', function(req, res) {
    let movie = {name: 'Spiderman', genre: 'Action', year: 2020}
    // send the response 
    res.json(movie)
}) */

// send a list of movies 
// http://localhost:8080/movies 
/*
app.get('/movies', function(req, res) {
    const movies = [{name: 'Spiderman', genre: 'Action', year: 2020}, {name: 'Batman', genre: 'Action', year: 2022}]
    // res.json will send JSON back to the client
    res.json(movies)
}) */

// start the server 
// app.listen(PORT Number, function fired when the server has started)
app.listen(8080, function() {
    console.log('Server is running...')
})

// http://localhost:8080 (Root URL/Base URL)