
const createMovieButton = document.getElementById('createMovieButton')
createMovieButton.addEventListener('click', () => {

    const movie = { title: 'Movie 100', genre: 'Action', year: 2022 }
    // perform a fetch request to create a movie 
    fetch('http://localhost:8080/movies', {
        method: 'POST', 
        headers: {
            'Content-Type': 'application/json'
        }, 
        body: JSON.stringify(movie) 
    }).then(response => response.json())
    .then(result => console.log(result))
})

async function getMovies() {
    const response = await fetch('http://localhost:8080/movies')
    const movies = await response.json()
    console.log(movies)
}

getMovies() 

