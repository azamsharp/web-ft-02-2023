// server side pages means that your server will return the complete page. 

const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')

// setting up mustache as a templating engine 
app.engine('mustache', mustacheExpress())
// the pages are located in the views directory
app.set('views', './views')
// extension for all the pages 
app.set('view engine', 'mustache')

// This helps Express to parse form submitted values 
app.use(express.urlencoded())

let movies = [{name: 'Batman', year: 2002}, {name: 'Spiderman', year: 2023}]

app.get('/contact-us', (req, res) => {
    res.render('contact-us')
})

app.get('/add-movie', (req, res) => {
    res.render('add-movie')
})

app.post('/add-movie', (req, res) => {

    const movieName = req.body.movieName
    const movieYear = req.body.movieYear

    const movie = { name: movieName, year: movieYear }
    movies.push(movie)

   res.redirect('/movies') // redirect to show all movies route
})

app.get('/movies', (req, res) => {
   
     // second argument to render is always an object 
    res.render('movies', { allMovies: movies })
    // res.render('movies', { movies: movies }) // fine too 
})

app.get('/', (req, res) => {
    let movie = { name: 'Spiderman', year: 2002 }
    // second argument to render is always an object 
    //res.render('index', { name: 'Spiderman', year: 2002 })
    // second argument to render is always an object 
    res.render('index', movie)
})

app.listen(8080, () => {
    console.log('Server is Running')
})
