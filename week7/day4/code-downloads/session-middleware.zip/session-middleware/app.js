const express = require('express')
const mustacheExpress = require('mustache-express')
const session = require('express-session')
const app = express()

// iwtgfhics2$

// jellyfish = a0ea5328f032f1557fbc5d6516c59cc85e7c0fa270c43085f9c994ef2915449b


let users = [
    {username: 'johndoe', password: 'password'}, 
    {username: 'marydoe', password: 'password'}
]



// middleware 
app.use(express.urlencoded())
// middleware 
app.use(express.static('public'))

// middleware for session 
app.use(session({
    secret: 'THISISSECRETKEY', 
    saveUninitialized: true, 
    resave: true 
}))

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

function logMiddleware(req, res, next) {
    console.log('LOGGED')
    // continue with the original request 
    next() 
}

// middleware 
app.use(logMiddleware)

app.get('/counter', (req, res) => {

    if(req.session) {
        req.session.counterValue = 0 
    }

    res.render('counter')
})

app.post('/counter', (req, res) => {

    if(req.session) {
        req.session.counterValue += 1 
    }

    res.render('counter', {counterValue: req.session.counterValue})

})


app.get('/first-page', (req, res) => {

    if(req.session) {
        req.session.username = 'johndoe'
        req.session.isLoggedIn = true 
    }

    res.render('first-page')
})

app.get('/second-page', (req, res) => {

    let username = ''

    if(req.session) {
         username = req.session.username
    }

    res.render('second-page', {username: username})
})


app.get('/', (req, res) => {
    res.render('index')
})


app.get('/login', (req, res) => {
    res.render('login')
})

/*
let users = [
    {username: 'johndoe', password: 'password'}, 
    {username: 'marydoe', password: 'password'}
]
*/

app.post('/login', (req, res) => {

    // access the username 
    const username = req.body.username

    // access the password 
    const password = req.body.password

    const persistedUser = users.find(user => {
        return user.username == username && user.password == password 
    })

    if(persistedUser) { 
        // if username and password were matching 
        if(req.session) {
            req.session.username = persistedUser.username 
        }

        // go here when username and password was correct 
        res.redirect('/dashboard')

    } else { // username or password were incorrect 
        res.render('login', {errorMessage: 'Username or password is incorrect'})
    }

})

app.get('/dashboard', (req, res) => {
    res.render('dashboard', {username: req.session.username})
})


app.get('/accounts', (req, res) => {
    res.render('accounts')
})

app.get('/hello', (req, res) => {
    res.send('Hello')
})

app.get('/api/greet', (req, res) => {
    res.json({message: 'Hello World'})
})

app.listen(3000,() => {
    console.log('Server is running...')
})