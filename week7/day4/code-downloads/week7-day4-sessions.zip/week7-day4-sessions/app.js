const express = require('express')
const mustacheExpress = require('mustache-express')
const session = require('express-session')
const app = express()

let users = [
    {username: 'johndoe', password: 'password'}, 
    {username: 'marydoe', password: 'password'}
]

// middleware 
app.use(express.urlencoded())

// session 
app.use(session({
    secret: 'THISISSECRETKEY', 
    saveUnitialized: true
}))



// register your routes after registering all your middlewares 
//app.use('/trips', tripsRouter)

// protect all the routes for admin 
//app.use('/admin', adminRouter, authenticationMiddleware)

// LOG MIDDLEWARE 

function logMiddleware(req, res, next) {
    console.log("[LOG MIDDLEWARE]")
    // continue with the original request 
    next() 
}

app.use(logMiddleware)

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

app.get('/login',  (req,res)=>{
    res.render('login')
})

function authenticationMiddleware(req, res, next) {
    if(req.session) {
        if(req.session.username) {
            // continue with the original request 
            next() 
        } else {
            res.redirect('/login')
        }
    } else {
        res.redirect('/login')
    }
}

// PROTECTED ROUTE 
app.get('/services',authenticationMiddleware,(req, res) => {
    res.send("SERVICES")
})

// PROTECTED ROUTE 
app.get('/accounts',authenticationMiddleware, (req, res) => {
    res.send("ACCOUNTS")
})

// PROTECTED ROUTE 
app.get('/profile',authenticationMiddleware, (req, res) => {
    res.send("PROFILE")
})

app.post('/login', (req, res) => {
    
    const username = req.body.username
    const password = req.body.password 

    const user = users.find(user => {
        return user.username == username && user.password == password
    })

    if(user) {

        // put something in the session 
        // do not put sensitive data into the session 
        if(req.session) {
            req.session.username = user.username 
        }

        // take them to the dashboard screen 
        res.render('dashboard')
    } else {
        // if the username or password is incorrect 
        res.render('login', {errorMessage: 'Username or password is incorrect.'})
    }

})

app.post('/counter', (req, res) => {
    if(req.session) {
        req.session.ctr += 1
    }

    //res.redirect('/counter')
    res.render('counter', {counter: req.session.ctr})
})

app.get('/counter', (req, res) => {
    res.render('counter', {counter: 0})
})


// configure session 


app.listen(8080,() => {
    console.log('Server is running...')
})