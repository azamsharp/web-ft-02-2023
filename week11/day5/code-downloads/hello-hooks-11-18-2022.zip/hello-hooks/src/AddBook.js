

function AddBook() {
    return (
        <h1>AddBook</h1>
    )
}

export default AddBook 