
// useState allows your functional components to hook into the state 
// useState allows functional components to use the state 
import React, { useState, useEffect } from 'react'

function App() {

  // count holds the state 
  // setCount is the function that will update the state 
  const [count, setCount] = useState(99)
  const [books, setBooks] = useState([])

  /*
  this.state = {
    count: 0
  } */

  // useEffect acts like componentDidMount - It is called when the first time the component is loaded 
  // useEffect also acts like componentDidUpdate - It is called when the state changes 
  // useEffect second argument is a dependency array. If the array is empty [] then useEffect is only called once
  // if array is [count] then useEffect is called at start and also when the count changes 
  useEffect(() => {
    fetchBooks()
  }, []) 

  const fetchBooks = () => {
    fetch('https://raw.githubusercontent.com/benoitvallon/100-best-books/master/books.json')
    .then(response => response.json())
    .then(books => {
      // put the books in the local state 
      setBooks(books)
    })
  }

  const handleIncrement = () => {
      // update the count 
      setCount(count + 1)
  }

  const bookItems = books.map((book, index) => {
    return <li key = {index}>
          <b>{book.title}</b>
    </li>
  })

  // whatever the function returns is the render 
  return (
    <>
      <h1>{count}</h1>
      <button onClick = {handleIncrement}>Increment</button>
      <ul>
        {bookItems}
      </ul>
    </>
  )
}

export default App;
