
import { useParams, useNavigate } from 'react-router-dom'
import React, { useEffect } from 'react'

function BookDetail() {

    const params = useParams() 
    const navigate = useNavigate() 

    // you can access params.bookId inside useEffect and then from inside useEffect make a call to the server to fetch additional information about the book. 

    useEffect(() => {

        // THIS CODE IS USING A FAKE URL AND WILL NOT WORK 
        fetch(`https://somebookstore/books/${params.bookId}`)
        .then(response => response.json())
        .then(book => {
            console.log(book)
        })


    }, [])


    const handleGoToAddBookScreen = () => {
        navigate('/add-book')
    }

    return (
        <>
            <h1>{params.bookId}</h1>
            <button onClick = {handleGoToAddBookScreen}>Take me to AddBook Screen</button>
        </>
    )
}

export default BookDetail