import Counter from "./Counter";
import { useState } from 'react'


function HomePage() {

    const [ctr, setCtr] = useState(0)

    const onIncrement = (value) => {
        console.log('onIncrement in HomePage called...')
        setCtr(value)
    }

    return (
        <div>
            <h1>Home Page</h1>
            <b>{ctr}</b>
            <Counter cat = "Cat 1" onIncrement = {onIncrement} />
        </div>
    )
}

export default HomePage 