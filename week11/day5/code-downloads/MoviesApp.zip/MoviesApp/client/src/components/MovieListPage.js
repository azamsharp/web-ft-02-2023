
import { useState, useEffect } from 'react'
import FeaturedMovie from './FeaturedMovie'
import MovieList from './MovieList'

function MovieListPage(props) {

    const [movies, setMovies] = useState([])

    // componentDidMount and componentDidUpdate
    useEffect(() => {
        fetchMovies() 
    },[])

    const fetchMovies = () => {
        
        fetch('http://www.omdbapi.com/?s=Batman&page=2&apikey=564727fa')
        .then(response => response.json()) 
        .then(result => {
            setMovies(result.Search)
        })
    }

    const onDeleteMovie = (movieId) => {
        console.log('MovieListPage ', movieId)
        // perform a fetch request to delete the movie from the database 
    }
    
    return (
        <div>
            <FeaturedMovie />
            <button onClick = {() => props.history.push('/') }>Take me to Home Page</button>
            <h1>List Of Movies</h1>
            <button>Action</button> <button>Kids</button> <button>Fiction</button>
            <MovieList movies = {movies} onDeleteMovie = {onDeleteMovie} />
        </div>
    )

}

export default MovieListPage