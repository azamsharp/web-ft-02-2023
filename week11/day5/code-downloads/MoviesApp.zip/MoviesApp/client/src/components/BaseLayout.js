
import { Component } from 'react'

export class BaseLayout extends Component {
    render() {
        return (
            <div>
                <h1>Menu</h1>
                 {this.props.children}
                <h6>Footer</h6>
            </div>

        )
    }
}
