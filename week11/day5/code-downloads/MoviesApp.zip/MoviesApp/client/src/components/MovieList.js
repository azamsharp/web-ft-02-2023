

function MovieList(props) {

    const deleteMovie = (movieId) => {
        props.onDeleteMovie(movieId)
    }

    const movies = props.movies 
    const movieItems = movies.map((movie) => {
        return <li key = {movie.imdbID}>
                <div>{movie.Title}</div>
                <button onClick = {() => deleteMovie(movie.imdbID)}>Remove</button>
            </li>
    })

    return (
        <div>
            {movieItems}
        </div>
    )
}

export default MovieList 