
import { useState, useEffect } from 'react'

function Counter(props) {

    // count is the state 
    // setCount is the function that will update the state 
    // useState is a function that will return tuple (state, function to update state) 
    // useState also initializes the value of the state 
    const [count, setCount] = useState(0)

    useEffect(() => {
        console.log('useEffect is called...')
        if(count > 0) {
            props.onIncrement(count)
        }
    },[count])

    const handleIncrement = () => {

        // class based component 
        /*
        this.setState({
            count: this.state.count + 1
        }, () => {
            // fired when the state has been successfully updated 
            console.log(this.state.count) // This value will be the newly updated value 
        }) */
        
        //console.log(this.state.count) // OLD 
        

        // The state will be updated ... eventually so the next line value of count is still old 
        setCount(count + 1)
        //console.log(count)
        //props.onIncrement(count) 
    }

    return (
        <div>
            <button onClick = {handleIncrement}>Increment</button>
        </div>
    )
}

export default Counter 