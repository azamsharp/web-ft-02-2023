

function MyMoviesPage() {

    return (
        <div>
              <h1>MyMoviesPage</h1>
        </div>
      
    )
}

export default MyMoviesPage