
import { withRouter } from 'react-router-dom'

function FeaturedMovie(props) {
    return (
        <div>
            <h1>Featured Movie</h1>
            <button onClick = {() => props.history.push('/') }>From Featured Movie to Home Page</button>
        </div>
    )
}

export default withRouter(FeaturedMovie) 