
import React, { Component } from 'react'
import BookList from './BookList'
import Counter from './Counter'
import SwitchView from './SwitchView'

class App extends Component {

  constructor() {
    super()
    // bind function allows to set the context for the function that is binding. 
    //this.handleIncrement = this.handleIncrement.bind(this)

    this.state = {
      counter: 0, 
      fullName: '', 
      age: '', 
      allBooks: [] 
    }

  }

  // fired when the component is mounted on the virtual dom 
  componentDidMount() {
    console.log('componentDidMount')
    fetch('https://raw.githubusercontent.com/benoitvallon/100-best-books/master/books.json')
    .then(response => response.json())
    .then(books => {
     // console.log(books)
      this.setState({
        allBooks: books 
      })
    })
  }

  handleFullNameChange = (e) => {
    console.log(e.target.value)
    //console.log('handleOnChange')
    this.setState({
      fullName: e.target.value 
    })
  }

  handleAgeChange = (e) => {
    this.setState({
      age: e.target.value 
    })
  }


  render() {

    console.log('render')
    return (

      <BookList books = {this.state.allBooks} />


      /*
      <div>
        <input type = "text" onChange = {this.handleFullNameChange} placeholder="Full Name" />
        <input type = "text" onChange = {this.handleAgeChange} placeholder="Age" />
        <button onClick = {this.handleSubmit}>Submit</button>
        {this.state.isSubmitted ? this.state.fullName : null}
        {this.state.isSubmitted ? this.state.age : null}
        <SwitchView />
      </div> */

    )
  }
}

export default App
