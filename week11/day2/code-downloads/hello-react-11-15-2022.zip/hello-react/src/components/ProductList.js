
import { Component } from 'react'

class ProductList extends Component {

    render() {

        const products = this.props.products
        const productItems = products.map((product) => {
           return <li key = {product.id}>
               <b>{product.title}</b>
               <p>{product.description}</p>
               <i>{product.price}</i>
             </li>
         })

        return <ul>{productItems}</ul>
    }
}

export default ProductList 