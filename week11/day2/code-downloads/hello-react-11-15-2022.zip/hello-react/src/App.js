import { Component } from 'react'
import ProductList from './components/ProductList'


class App extends Component {

  constructor() {
    // super is going to call the constructor of the parent class which in this case is Component since App inherits/extends from the Components class
    super() 
    
    // state in React 
    // private/local state 
    // only available for the component
    this.state = {
      counter: 99, 
      name: 'John Doe', 
      products: [] 
    }


  }

  // componentDidMount is fired when your React component is attached to the virtual DOM 
  componentDidMount() {
    fetch('https://api.escuelajs.co/api/v1/products?offset=0&limit=10')
    .then(response => response.json())
    .then(products => {
      // put the products in the local/private state 
      this.setState({
        products: products 
      })
    })
  }

  handleIncrement = () => {
    // WRONG WRONG WRONG WRONG WRONG 
    // this.state.counter += 1 // WRONG 
     // WRONG WRONG WRONG WRONG WRONG 

    // STATE CANNOT BE CHANGED, STATE CAN ONLY BE REPLACED
    // When setState is called, it AUTOMATICALLY calls the render function
    this.setState({
      counter: this.state.counter + 1 
    })

    // This will NOT give me the updated value 
    // The reason is that setState updates the state asyncronously 
    console.log(this.state.counter)

    /*
    // second argument is function/callback fired after the state has been updated 
    this.setState({
      counter: this.state.counter + 1
    }, () => { 

    })
    */


  }

/*
  handleIncrement() {
    this.counter++ 
    console.log(this.counter)
  } */

  // render function is required for class based components
  // DO NOT CALL setState in render. Your machine will FREEZE and your app will CRASH. Infinite LOOP 
  render() {

    return (
      <>
        <h1>{this.state.counter}</h1>
        <button onClick = {this.handleIncrement}>Increment</button>
        <ProductList products = {this.state.products} />
      </>
    )
  }

}

export default App 