import { Component } from "react";



export class Header extends Component {
    render() {
        return (
            <h1>Header</h1>
        )
    }
}

export class Footer extends Component {
    render() {
        return (
            <h1>Footer</h1>
        )
    }
}

