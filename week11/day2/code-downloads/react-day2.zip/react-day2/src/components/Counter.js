import { Component } from "react";


class Counter extends Component {

    // initialization is handled in the constructor 
    constructor() {
        super() // this means calling the constructor of the Component class 

        // state or local state or private state 
        this.state = {
            ctr: 0
        }

        // bind function allows to set the context for the function that is binding. 
        //this.handleIncrement = this.handleIncrement.bind(this)
    }

    handleIncrement = () => {
        
        // DON'T DO THIS 
        // STATE IS IMMUTABLE YOU CANNOT CHANGE
        //this.state.ctr++ 

        // replace the existing state with a brand new state 
        // When you call setState, React automatically calls render function
        this.setState({
            ctr: this.state.ctr + 1
        },() => { // this optional function is called when the state is updated...  
            console.log(this.state.ctr)
        })

        //console.log(this.state.ctr)

    } 

    /*
    handleIncrement() {
        console.log(this)
        // this refers to the current object/instance of the Counter class 
        this.count++ 
        console.log(this.count)
        console.log("handleIncrement fired!")
    } */

    render() {
       
        return (
            <div>
                <h1>{this.state.ctr}</h1>
                <button onClick = {this.handleIncrement} >Increment</button>
            </div>
        )
    }
}

export default Counter 