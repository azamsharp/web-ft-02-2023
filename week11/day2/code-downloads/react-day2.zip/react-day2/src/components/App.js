import React, {Component} from 'react'

import { Header, Footer } from './BaseLayout'
import CatFactList from './CatFactList'
import Counter from './Counter'
import SwitchView from './SwitchView'
import TodoList from './TodoList'

// App class inherits from a Component class 
class App extends Component {

    constructor() {
        super()

        this.state = {
            facts: [], 
            counter: 10  
        }
    }

    componentDidMount() {
        
        console.log("componentDidMount")
        fetch('https://cat-fact.herokuapp.com/facts')
        .then(response => response.json())
        .then(results => {

            // setState performs a partial update 
            // which means counter is not kicked out and is automatically copied in the new state 
            this.setState({
                facts: results
            })

        })

    }

    render() {
        console.log("render")
        return (
            <div>
                <h1>Hello World</h1>
                 {/* <Counter />  */}

                 <CatFactList facts = {this.state.facts} />

                 <TodoList />
                 <SwitchView />
            </div>
        )
    }
}

export default App 