import { Component } from "react";

class SwitchView extends Component {

    constructor() {
        console.log("constructor in SwitchView")
        super() 
        this.state = {
            isOn: true 
        }
    }

    handleSwitchClick = () => {
        this.setState({
            isOn: !this.state.isOn
        })
    }

    render() {
        console.log("render in SwitchView")
        return (
            <button onClick={this.handleSwitchClick}>{this.state.isOn ? "ON": "OFF"}</button>
        )
    }

}

export default SwitchView 