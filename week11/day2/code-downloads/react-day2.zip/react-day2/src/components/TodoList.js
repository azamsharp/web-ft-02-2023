import { Component } from "react";


class TodoList extends Component {

    constructor() {
        super() 

        this.state = {
            task: ""
        }
    }

    handleOnChange = (e) => {
        this.setState({
            task: e.target.value
        })
    }

    render() {
        return (
            <div>
                <input type="text" onChange={this.handleOnChange} />
            </div>
        )
    }

}

export default TodoList 