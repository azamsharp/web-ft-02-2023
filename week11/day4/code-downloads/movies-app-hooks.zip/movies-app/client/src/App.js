
import './App.css';
// useState is a hook, which allows react components to use State 
import React, { useState, useEffect } from 'react'
import FancyCounter from './FancyCounter';
import BookList from './BookList';

function App() {

  // count is the actual value of the state 
  // setCount is the function that will update the state 
  const [count, setCount] = useState(99)
  const [name, setName] = useState('')
  const [books, setBooks] = useState([])

  // componentDidMount - Fires when the component is mounted on virtual DOM
  // componentDidUpdate - Fires when state changes 
  useEffect(() => {
    getAllBooks()
  }, []) // dependency array useEffect is called when any state value in the array changes 

  const getAllBooks = () => {
    fetch('https://raw.githubusercontent.com/benoitvallon/100-best-books/master/books.json')
      .then(response => response.json())
      .then(books => {
        console.log(books)
        setBooks(books)
      })
  }

  const handleIncrement = () => {
    setCount(count + 1)
  }

  const handleAssignName = () => {
    setName('John Doe')
  }

  const handleNameChange = (e) => {
    setName(e.target.value)
  }

  return (
    <div>
      <h1>{count}</h1>
      <h3>{name}</h3>
      <button onClick={handleIncrement}>Increment</button>
      <button onClick={handleAssignName}>Assign Name</button>
      <input type="text" placeholder="Enter name" onChange={handleNameChange} />
      <FancyCounter ctr={count} />
      <BookList books = {books} />
    </div>
  )

}

export default App
