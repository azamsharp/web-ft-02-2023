

function FancyCounter(props) {

    return (
        <h1>FancyCounter - {props.ctr}</h1>
    )

}

export default FancyCounter