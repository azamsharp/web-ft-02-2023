
import React, { useState } from 'react'

function LoginPage() {

    //const [username, setUserName] = useState('')
    //const [password, setPassword] = useState('')
    const [user, setUser] = useState({})

    // JS 
    //let car = {make: 'Honda', model: 'Accord', vin: '34567', isElectric: false}
    
    /*
    let anotherCar = {
        make: car.make, 
        model: car.model, 
        vin: car.vin, 
        isElectric: car.isElectric,
        color: 'white'
    } */
    /*
    let anotherCar = {
        ...car, // spread operator 
        color: 'white'
    } */



    const handleLoginChange = (e) => {
        setUser({
            // copy the old state/ spread operator  
            ...user, 
            [e.target.name]: e.target.value
        })
    }

    return (
        <div>
            <h1>Login</h1>
            <input type = "text" name = "username" onChange = {handleLoginChange} placeholder = "User name" />
            <input type = "password" name = "password" onChange = {handleLoginChange} placeholder = "Password" />
            <button>Login</button>
        </div>
    )
}

export default LoginPage