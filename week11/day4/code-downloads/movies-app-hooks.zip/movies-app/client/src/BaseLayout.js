import { NavLink } from "react-router-dom"

// Named Exports 
export function BaseLayout(props) {
    return (
        <div>
            <Menu /> 
            {props.children}
        </div>
    )
}

export function Menu() {
    return (
        <div>
            <NavLink to = "/">Home</NavLink>
            <NavLink to = "/login">Login</NavLink>
        </div>
    )
}



//export default BaseLayout