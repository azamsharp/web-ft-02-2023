const express = require('express')
const app = express() 
const cors = require('cors')

app.use(cors())
app.use(express.json())

// create a books array which contains 2 books
// each book can have a 'name' and an 'id' 

const books = [
    {name: 'Book1', id:'1'},
    {name: 'Book2', id:'2'}
]


// api/books POST 
app.post('/api/books', (req, res) => {
    const name = req.body.name
    const book = {id: books.length + 1, name: name}
    books.push(book)
    res.json(book)
})

// /api/books GET 
app.get('/api/books', (req, res) => {
    res.json(books)
})

app.listen(8080, () => {
    console.log('Server is running...')
})