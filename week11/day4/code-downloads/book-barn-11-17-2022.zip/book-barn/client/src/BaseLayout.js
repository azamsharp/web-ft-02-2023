
import { Component } from 'react'
import App from './App'
import Menu from './Menu'

class BaseLayout extends Component {
    render() {
        return (
            <>
                <Menu />
                <b>Deal 50% OFF</b>
                {this.props.children}
                <h6>Copyright 2022</h6>
            </>
        )
    }
}

export default BaseLayout 

