import { Component } from 'react'
import Menu from './Menu'

class AddBook extends Component {

    constructor() {
        super()
        this.state = {
            bookName: ''
        }
    }

    handleAddBook =() => {
        fetch('http://localhost:8080/api/books', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({name: this.state.bookName})
        }).then(response => response.json())
        .then(newBook => {
            // go to the App page to view all the books 
        })
    }



    handleOnChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    // http://localhost:8080/api/books POST 

    render() {

        return (
            <>
                <input type='text' name='bookName' placeholder='Enter book name' onChange={this.handleOnChange} />
                <button onClick = {this.handleAddBook}>Add Book</button>
            </>
        )
    }
}

export default AddBook 