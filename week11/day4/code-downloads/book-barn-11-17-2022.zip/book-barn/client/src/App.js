import { Component } from 'react'
import Menu from './Menu'

class App extends Component {

  constructor() {
    super()
    this.state = {
      books: []
    }
  }

  render() {

    const books = this.state.books
    const bookItems = books.map((book) => {
      return <li>{book.name}</li>
    })
    return (
      <>

        <h1>App</h1>
        <ul>
          {bookItems}
        </ul>
      </>
    )
  }

  componentDidMount() {
    fetch('http://localhost:8080/api/books')
      .then(response => response.json())
      .then(books => {
        this.setState({
          books: books
        })
      })
  }
}

export default App;
