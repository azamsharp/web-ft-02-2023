
import React, { useState, useEffect } from 'react'

function MovieList() {

    const [movies, setMovies] = useState([]) 
    const [count, setCount] = useState(0)
    const [coffee, setCoffee] = useState({})

        
    // Similar to componentDidMount and componentDidUpdate
    useEffect(() => {
       getAllMovies()
    },[]) 

    const getAllMovies = () => {
        
        fetch('http://www.omdbapi.com/?s=Batman&page=2&apikey=564727fa')
        .then(response => response.json())
        .then(result => {
            console.log(result.Search)
            setMovies(result.Search)
        })
    }

    const handleGetAllMovies = () => {
        getAllMovies() 
    }

    /*
    let car = {make: "Honda", model: "Accord"}

    // spread operator in JavaScript is used to copy properties and values 
    // from one object to other 
    let anotherCar = {
        ...car, 
        color: 'red'
    } */


    const handleOnChange = (e) => {
            setCoffee({
                ...coffee,
                [e.target.name]: e.target.value
            })
    }
    
    const handleCoffeeOrderSubmit = () => {

        fetch('https://island-bramble.glitch.me/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }, 
            body: JSON.stringify(coffee)
        })

    }

    const movieItems = movies.map(movie => {
        return <li key = {movie.imdbID}>{movie.Title}</li>
    })

    return (
        <div>
        <h1>MovieList</h1>
        <button onClick = {() => setCount(count + 1)}>Increment Count</button>
        <button onClick = {handleGetAllMovies}>Get All Movies</button>
        {movieItems}

        <h1>New Coffee Order</h1>
        <input type = "text" placeholder="name" onChange = {handleOnChange} name = "name"></input> 
        <input type = "text" placeholder="coffee name" onChange = {handleOnChange} name = "coffeeName"></input> 
        <input type = "text" placeholder="total" onChange = {handleOnChange} name = "total"></input> 
        <input type = "text" placeholder="size" onChange = {handleOnChange} name = "size"></input> 
        <button onClick = {handleCoffeeOrderSubmit}>Submit</button>
        </div>
    )

}

export default MovieList