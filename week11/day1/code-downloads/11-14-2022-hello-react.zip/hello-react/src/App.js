
// CLASS BASED COMPONENT 

import { Component } from "react";
// ./components/Greet means from the src folder find components folder and then find the js file called Greet
import Greet from "./components/Greet";
import TodoList from "./components/TodoList";

// App inherits from Component 
// The name of the Component MUST start with Uppercase letter 
// Don't put underscores in the class name 
// ProductList is good 
// Product_List is NOT good 
// JSX = JavaScript and XML
// In a React Component, render function is REQUIRED  
// Parent component can pass data to the child component through the use of properties 
class App extends Component {

  constructor() {
    // call the constructor of the parent class (Component)
    super()
    this.tasks = [{ name: 'Wash car' }, { name: 'Clean house' }]
    this.pendingTasks = [{name: 'Do grocery'}, {name: 'Feed dog'}]
  }

  render() {
    return (
      <>
        <TodoList tasks = {this.tasks} />
        <Greet name = "Steven" />
        <TodoList tasks = {this.pendingTasks} />
      
      </>
    )
  }
}

// exporting the App Component so other files can import it 
export default App