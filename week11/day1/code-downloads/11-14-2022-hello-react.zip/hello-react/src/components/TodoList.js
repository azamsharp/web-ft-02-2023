import { Component } from "react";

class TodoList extends Component {

    render() {

        const taskItems = this.props.tasks.map((task, index) => {
            return <li key = {index}>{task.name}</li>
        })

        return (
           <ul>
                {taskItems}
           </ul>
        )
    }
}

export default TodoList 