import { Component } from "react";
import TodoList from "./TodoList";


class Dashboard extends Component {

    constructor() {
        // call the constructor of the parent class (Component)
        super()
        this.tasks = [{ name: 'Wash car' }, { name: 'Clean house' }]
        this.pendingTasks = [{name: 'Do grocery'}, {name: 'Feed dog'}]
        this.customers = ["Alex", "Steven"]
      }

    render() {

        const customerItems = this.customers.map((customer) => {
            return <li>{customer}</li>
        })

        return (
            <>
            <h1>Dashboard</h1>
            <TodoList tasks = {this.tasks} />
            {customerItems}

            <Article title = "Hello World" content = "This is the content of the article" noOfComments = "12" noOfLikes = "45" ></Article>

            <Article title = "Hello JS" content = "This is the content of the JS" noOfComments = "23" noOfLikes = "56" ></Article>

            </>
        )
    }
}

export default Dashboard 