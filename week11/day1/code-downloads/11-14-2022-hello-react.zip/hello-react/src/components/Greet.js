import { Component } from "react";

class Greet extends Component {
    render() {
        return (
            <>
            <h1>Greet {this.props.name}!</h1>
            <h4>And my age is {this.props.age}</h4>
            </>
        )
    }
}

export default Greet 