import { Component } from "react";


// named export
export class Menu extends Component {

    render() {
        return (
            <h1>Menu</h1>
        )
    }
}

// named export 
export class Footer extends Component {
    render() {
        return (
            <h1>Footer</h1>
        )
    }
}

//export default Menu