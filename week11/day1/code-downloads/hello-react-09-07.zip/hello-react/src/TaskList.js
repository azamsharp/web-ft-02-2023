import { Component } from "react";


class TaskList extends Component {

    /*
    constructor() {
        // super is the constructor of the parent class (Component)
        super()
        this.tasks = [
            { name: 'Wash car' },
            { name: 'Do grocery' }
        ]
    } */

    render() {

        const taskItems = this.props.allTasks.map((task, index) => {
            return <li key = {index}>{task.name} - {task.priority}</li>
        })

        return (
            <ul>
                {taskItems}
            </ul>
        )
    }

}

export default TaskList