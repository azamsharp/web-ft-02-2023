
import React, { Component } from 'react'
import Footer from './Footer'
import Greet from './Greet'
import Header from './Header'
import TaskList from './TaskList'

// App component inherits from the Component class 
class App extends Component {
  // render function is a required function that must be implemented in your component 
  render() {

    const tasks = [
      {name: 'Mow lawn', priority: 'high'}, 
      {name: 'Wash car', priority: 'low'}
    ]

    // JSX JavaScript and XML 
    return (
      <div>
        <Header />
        <Greet fullName = 'Mary' age = '34' />
        <Greet fullName = 'John' age = '56' />
        <TaskList allTasks = {tasks} />
        <Footer />
      </div>

    )
  }
}

export default App
