import { Component } from "react";

class Greet extends Component {

    render() {
        return (
            <h1>Hello {this.props.fullName} - {this.props.age}</h1>
        )
    }

}

export default Greet 