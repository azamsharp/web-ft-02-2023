import { Component } from "react";
import './Header.css'

class Header extends Component {
    render() {
        return <h1 className = 'header'>Header</h1>
    }
}

export default Header