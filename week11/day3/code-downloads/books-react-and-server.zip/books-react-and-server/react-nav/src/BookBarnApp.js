/*
import logo from './logo.svg';
import './App.css';
import { Component } from 'react';

class App extends Component {

    constructor() {
      super() 
      this.state = {
        allBooks: [] 
      }
    }

    render() {

      //  https://raw.githubusercontent.com/benoitvallon/100-best-books/master/static/images/absalom-absalom.jpg
      let imageLink = 'images/things-fall-apart.jpg'

      let finalImageUrl = `https://raw.githubusercontent.com/benoitvallon/100-best-books/master/static/${imageLink}`

      console.log(finalImageUrl)

      return (
        <div>
          <h1>App</h1>
          <img src = {finalImageUrl} />
        </div>
      )
    }

    componentDidMount() {
      fetch('https://raw.githubusercontent.com/benoitvallon/100-best-books/master/books.json')
      .then(response => response.json())
      .then(books => {
        this.setState({
          allBooks: books
        })
      })
    }

}

export default App; 
*/
