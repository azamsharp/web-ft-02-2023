import { Component } from "react";

class BookListPage extends Component {

    componentDidMount() {

        fetch('http://localhost:8080/api/books')
        .then(response => response.json())
        .then(books => {
            console.log(books)
        })

    }

    render() {
        return (
            <h1>BookListPage</h1>
        )
    }

}

export default BookListPage