import { Component } from "react";
import { NavLink } from "react-router-dom";
import './Menu.css'

class Menu extends Component {

    render() {
        return (
            <div id = "menu">
                <NavLink to = "/"><div>Home</div></NavLink>
                <NavLink to = "/movies"><div>Movies</div></NavLink>
                <NavLink to = "/login"><div>Login</div></NavLink>
                <NavLink to = "/books"><div>View All Books</div></NavLink>
                <NavLink to = "/add-book"><div>Add Book</div></NavLink>
            </div>
        )
    }

}

export default Menu 