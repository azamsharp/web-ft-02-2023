
import './App.css'
import { Component } from 'react';
import MovieList from './MovieList';
import Counter from './Counter';
import Menu from './Menu';

class App extends Component {

    constructor() {
      super() 

      this.state = {
        counter: 0 
      }
    }

    valueSubmitted = (value) => {
      this.setState({
        counter: value 
      })
    }

    render() {

      return (
        <div>
         
          {this.state.counter}
          <Counter age = "56" onValueSubmitted = {this.valueSubmitted} />
        </div>
      )
    }

  

}

export default App;
