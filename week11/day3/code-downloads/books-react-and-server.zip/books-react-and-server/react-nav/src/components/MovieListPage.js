import { Component } from "react";
import MovieList from "./MovieList";


class MovieListPage extends Component {

    constructor() {
        super() 
        
        this.state = {
            movies: []
        }
    }

    render() {
        return (
            <MovieList allMovies = {this.state.movies} />
        )
    }

    componentDidMount() {

        fetch('http://www.omdbapi.com/?s=Batman&page=2&apikey=564727fa')
        .then(response => response.json())
        .then(result => {
          this.setState({
            movies: result.Search 
          })
        })
  
      }

}

export default MovieListPage 