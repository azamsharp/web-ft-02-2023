import { Component } from "react";


class Counter extends Component {

    constructor() {
        super() 

        this.state = {
            counterValue: 0 
        }
    }

    handleFirstNumberChange = (e) => {

        this.setState({
            counterValue: parseInt(e.target.value)
        })
    }

    handleSubmit = () => {
        // this.props.age
        this.props.onValueSubmitted(this.state.counterValue) 
    }

    render() {
        return (
            <div>
                 <h1>Counter</h1>
                 <input type = "text" onChange = {this.handleFirstNumberChange} placeholder = "Enter first number" />
                 <button onClick = {this.handleSubmit}>Submit</button>
            </div>
        )
    }

}

export default Counter 