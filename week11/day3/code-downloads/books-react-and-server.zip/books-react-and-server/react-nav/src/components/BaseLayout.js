import { Component } from "react";
import App from "./App";
import Menu from "./Menu";
import MovieListPage from "./MovieListPage";


class BaseLayout extends Component {

    render() {
        return (
            <div>
                <Menu />
                {this.props.children}
                <i>Copyright 2022</i>
            </div>
        )
    }

}

export default BaseLayout