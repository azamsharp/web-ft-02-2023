import { Component } from "react";


class LoginPage extends Component {

    render() {
        return (
            <h1>LoginPage</h1>
        )
    }
}

export default LoginPage