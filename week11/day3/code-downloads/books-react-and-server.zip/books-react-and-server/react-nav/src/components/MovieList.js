import { Component } from "react";


class MovieList extends Component {

    render() {

        const movieItems = this.props.allMovies.map((movie) => {
            return (
                
                <li key = {movie.imdbID}>
                    <label>{movie.Title}</label>
                    <img src = {movie.Poster} />
                </li>
                
            )
        })

        return (
            <ul>
                {movieItems}
            </ul>
        )
    }

}

export default MovieList 