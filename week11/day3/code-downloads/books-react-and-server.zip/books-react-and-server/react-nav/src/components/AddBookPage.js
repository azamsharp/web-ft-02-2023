import { Component } from "react";


class AddBookPage extends Component {

    constructor() {
        super()

        this.state = {
            bookName: '',
            bookISBN: ''
        }
    }

    handleOnChange = (e) => {
       this.setState({
           [e.target.name]: e.target.value
       })
    }

    handleAddBookSubmit = () => {

        fetch('http://localhost:8080/api/books', {
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json'
            }, 
            body: JSON.stringify({
                name: this.state.bookName, 
                isbn: this.state.bookISBN
            })
        }).then(response => response.json())
        .then(result => {
            if(result.success) {
                // take the user to view all books 
                this.props.history.push('/books')
            }
        })

    }

    render() {
        return (
            <div>
            <h1>Add Book Page</h1>
            <input type = "text" name = 'bookName' onChange = {this.handleOnChange} placeholder = "Enter name" />
            <input type = "text" name = 'bookISBN' onChange = {this.handleOnChange} placeholder = "Enter ISBN" />
            <button onClick = {this.handleAddBookSubmit}>Submit</button>
            </div>
        )
    }

}

export default AddBookPage