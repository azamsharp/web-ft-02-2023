
const express = require('express')
const cors = require('cors')
const app = express() 

app.use(cors())
app.use(express.json())

const books = [
    {name: 'Book 1', isbn: '4567GHJ'}, 
    {name: 'Book 2', isbn: 'TGYHUJ'}
]

app.get('/api/books', (req, res) => {
    res.json(books)
})

app.post('/api/books', (req, res) => {

    const name = req.body.name
    const isbn = req.body.isbn 

    const book = {name: name, isbn: isbn }

    books.push(book)
    res.json({success: true})

})

app.listen(8080, () => {
    console.log('Server is running...')
})