
import { Component } from 'react'
import AddBook from './AddBook'
import Counter from './Counter'

class App extends Component {

  constructor() {
    super() 
    // create the state 
    this.state = {
      books: [], 
      counter: 0  
    }
  }

  componentDidMount() {
    // http://localhost:8080/api/books
    fetch('http://localhost:8080/api/books')
    .then(response => response.json())
    .then(books => {
       // STATE CANNOT BE CHANGED, STATE CAN ONLY BE REPLACED
        // WRONG WRONG WRONG WRONG WRONG 
         // WRONG WRONG WRONG WRONG WRONG 
        // this.state.books = books   <----------------------------------------
       // WRONG WRONG WRONG WRONG WRONG 
        // WRONG WRONG WRONG WRONG WRONG 
         // WRONG WRONG WRONG WRONG WRONG 
         this.setState({
          books: books 
         })

        // console.log(this.state.books) // WHAT WILL THIS PRINT 
    }) 
  }

  onIncrementCallback = (ctrValue) => {
    this.setState({
      counter: ctrValue
    })
  }

  render() {

    const books = this.state.books 
    const bookItems = books.map((book) => {
      return <li>{book.name}</li>
    })

    return (
      <ul>
       <h1>{this.state.counter}</h1>
       
        <Counter onIncrement = {this.onIncrementCallback} />
      </ul>
    )
  }

 


}

export default App;
