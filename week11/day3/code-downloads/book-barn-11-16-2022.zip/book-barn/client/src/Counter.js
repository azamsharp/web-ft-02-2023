
import { Component } from 'react'

class Counter extends Component {

    constructor() {
        super() 
        this.state = {
            counter: 0 
        }
    }

    handleIncrement = () => {
       this.setState({
        counter: this.state.counter + 1 
       }, () => {
        this.props.onIncrement(this.state.counter)
       })

      

       // access the onIncrement property 
       // this.props.onIncrement will call the onIncrementCallback function defined in App.js 
       //this.props.onIncrement(this.state.counter) 

    }

    render() {
        return (
            <button onClick = {this.handleIncrement}>Increment</button>
        )
    }
}

export default Counter 