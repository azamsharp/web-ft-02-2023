import { Component } from 'react'

class AddBook extends Component {

    constructor() {
        super() 
        this.state = {
            bookName: '', 
            authorName: ''
        }
    }

    handleAddBook = () => {
        fetch('http://localhost:8080/api/books', {
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json'
            }, 
            body: JSON.stringify({ name: this.state.bookName }) 
        })
    }

    handleOnChange = (e) => {

        console.log(e.target.name) 

        this.setState({
            // [e.target.name] will create a property inside the object, which will be based on the name of the TextBox 
            // e.target.value is the value inside the TextBox 
            [e.target.name]: e.target.value 
        }) 
    }

    render() {
        return (
            <>  
                <h1>Add Book</h1>
                <input type = 'text' name = 'bookName' placeholder='Enter book name' onChange= {this.handleOnChange} />
                <input type = 'text' name = 'authorName' placeholder = 'Enter author name' onChange= {this.handleOnChange} />
                <button onClick = {this.handleAddBook}>Add Book</button>
            </>
        )
    }
}

export default AddBook 