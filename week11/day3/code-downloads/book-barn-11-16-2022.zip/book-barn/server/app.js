
const express = require('express')
const app = express() 
const cors = require('cors')

app.use(cors())
app.use(express.json()) // tell the server how to parse JSON 

// create an array of books 
let books = [
    { id: 1, name: 'Book1'},
    { id: 2, name: 'Book2'}
]

// adding a new book 
app.post('/api/books', (req, res) => {
    const bookName = req.body.name
    // create an object with a property called name 
    const book = { id: books.length + 1, name: bookName}
    // add book object to the books array 
    books.push(book)
    res.json({success: true, message: 'Book has been inserted.'})
})

app.get("/api/books", (req, res) => {
    res.json(books)
})

app.listen(8080, () => {
    console.log('Server is running...')
})