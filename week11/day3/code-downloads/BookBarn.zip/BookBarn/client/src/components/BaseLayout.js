import { Component } from "react";
import { NavLink } from "react-router-dom";
import App from './App'

export class BaseLayout extends Component {

    render() {
        return (
            <div>
                <Menu />
                   {this.props.children}
                <Footer />
            </div>
        )
    }
}

export class Menu extends Component {
    render() {
        return (
            <div>
                <NavLink to = "/"><div class="bootstrap-link">Home</div></NavLink>
                <NavLink to = "/movies">Movies</NavLink>
                <NavLink to = "/add-movie"><div>Add Movie</div></NavLink>
            </div>
        )
    }
}

export class Footer extends Component {
    render() {
        return (
            <h1>Copyright 2022</h1>
        )
    }
}