import { Component } from "react";


class MovieList extends Component {
    render() {

        const movies = this.props.movies 

        const movieItems = movies.map((movie) => {
            return <li>{movie.name}</li>
        })

        return (
            <div>
                <h1>MovieList</h1>
                {movieItems}
            </div>
        )
    }
}

export default MovieList 