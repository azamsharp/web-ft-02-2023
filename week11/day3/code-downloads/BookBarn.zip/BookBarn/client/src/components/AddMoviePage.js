import { Component } from "react";


class AddMoviePage extends Component {

    constructor() {
        super() 
        this.state = {
            name: "", 
            genre: ""
        }
    }

    handleOnChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value 
        })
    }   

    handleSave = () => {

        fetch('http://localhost:8080/movies',{
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json'
            }, 
            body: JSON.stringify({
                name: this.state.name, 
                genre: this.state.genre 
            })
        }).then(response => response.json())
        .then(result => {
            if(result.success) {
                // take the user to the movies page to show all movies 
                this.props.history.push('/movies')
            }
        })

    }

    render() {
        return (
            <div>
                <h1>Add Movie</h1>
                <input type="text" onChange = {this.handleOnChange} placeholder="Movie Name" name = "name" />
                <input type="text" onChange = {this.handleOnChange} placeholder="Movie Genre" name = "genre" />
                <button onClick = {this.handleSave}>Save</button>
            </div>
        )
    }
}

export default AddMoviePage