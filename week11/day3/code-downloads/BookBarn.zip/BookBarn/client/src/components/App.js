
import { Component } from 'react'

class App extends Component {

  constructor(){
    super()

    this.state = {
      name: "",
      place: "", 
      ready: false 
    }
  }

  /*
  handleOnNameChange = (e) => {
    this.setState({
      name: e.target.value
    })
  } 

  handleOnPlaceChange = (e) => {
    this.setState({
      place: e.target.value
    })
  }  */

  handleOnChange = (e) => {

      this.setState({
        [e.target.name]: e.target.value 
      })
  }

  handleSubmit = () => {
    this.setState({
      ready: true 
    })
  }
  
  render() {
    return (
      <div>
        <h1>App</h1>
        <input type="text" onChange = {this.handleOnChange} name = "name" />
        <input type="text" onChange = {this.handleOnChange} name = "place" />
        <button onClick = {this.handleSubmit}>Submit</button>

       {this.state.ready ? this.state.name: ""}
       {this.state.ready ? this.state.place: ""}
        
      </div>
    )
  }

  componentDidMount() {

  }


}

export default App 


