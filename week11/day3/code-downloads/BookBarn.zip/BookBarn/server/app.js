

const express = require('express')
const cors = require('cors')
const app = express() 

app.use(cors())
app.use(express.json())

let movies = [
    {name: 'Spiderman', genre: 'Action'}, 
    {name: 'Batman', genre: 'Action'}, 
    {name: 'Finding Nemo', genre: 'Kids'}
]

app.get('/movies', (req, res) => {
    res.json(movies)
})

app.post('/movies', (req, res) => {

    const name = req.body.name 
    const genre = req.body.genre 

    let movie = {name: name, genre: genre}
    movies.push(movie)

    res.json({success: true, message: 'Movie has been added!'})
})


app.listen(8080, () => {
    console.log('Server is running...')
})