
const nameTextBox = document.getElementById("nameTextBox")

const saveNameButton = document.getElementById("saveNameButton")
saveNameButton.addEventListener('click',() => {
    // save button pressed 
    
    // 1) get the name from the textbox 

    // 2) save the name to local storage 
})


const loadNameButton = document.getElementById("loadNameButton")
loadNameButton.addEventListener('click',() => {
    // load button pressed 

    // 1) load the name from local storage
})
