
const jwt = require('jsonwebtoken')
//const models = require('../models')

function authenticate(req, res, next) {

     // access the headers 
     const header = req.headers['authorization']
     if(header) {
         const token = header.split(' ')[1] // token 
         // decode the token 
         try {
         const decoded = jwt.verify(token, 'SECRETKEYJWT')
         if(decoded) {
             const username = decoded.username 
             const authUser = users.find(user => user.username == username)
             if(authUser) {
                 // continue with the original request 
                next() 
             } else {
                 res.json({error: 'Unable to authenticate'})
             }
         } else {
             res.json({error: 'Unable to authenticate'})
         }
        } catch {
            res.json({error: 'Unable to authenticate'})
        }

 
     } else {
         res.json({error: 'Required authorization headers are missing.'})
     }
}


module.exports = authenticate 