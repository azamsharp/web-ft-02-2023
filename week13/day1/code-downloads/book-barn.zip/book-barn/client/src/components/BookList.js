
import { useState, useEffect } from 'react'

function BookList(props) {

    const [books, setBooks] = useState([])

    useEffect(() => {
        fetchBooks() 
    }, [])

    const fetchBooks = () => {

        const token = localStorage.getItem('jwt')
        const username = localStorage.getItem('username')

        // inject the username into the url 
        // remove the hard-coded johndoe from the url 
        fetch(`http://localhost:8080/api/${username}/books`, {
            method: 'GET', 
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        })
        .then(response => response.json())
        .then(result => {
            if(result.error) {
                console.log(result.error)
            } else {
                setBooks(books)
            }
        })
    }

    const bookItems = books.map(book => {
        return <li>{book.name}</li>
    })

    return (
        <ul>{bookItems}</ul>
    )
}

export default BookList 