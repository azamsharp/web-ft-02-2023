import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function Login() {
    
    const [user, setUser] = useState({})
    const navigate = useNavigate() 

    const handleOnChange = (e) => {
        setUser({
            ...user, 
            [e.target.name]: e.target.value
        })
    }

    const handleSubmit = () => {

        fetch('http://localhost:8080/api/login', {
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json'
            }, 
            body: JSON.stringify(user)
        })
        .then(response => response.json())
        .then(result => {

            if(result.success) {
                // get the token 
                const token = result.token 
                const username = result.username 
                // put the token in local storage 
                localStorage.setItem('jwt', token)
                localStorage.setItem('username', username)
                // go to the book list component 
                navigate('/books')
            }

            console.log(result)
        })
    }

    return (
        <>
            <input onChange = {handleOnChange} name = "username" type = "text" placeholder = "Enter username"  /> 
            <input  onChange = {handleOnChange} name = "password" type = "text" placeholder = "Enter password" />
            <button onClick={handleSubmit}>Login</button>
        </>
    )

}

export default Login