
const express = require('express')
const jwt = require('jsonwebtoken')
const cors = require('cors')
const authenticate = require('./middlewares/authMiddleware')
const app = express() 

require('dotenv').config()

app.use(cors())
app.use(express.json())

global.users = [
    {username: 'johndoe', password: 'password'}, 
    {username: 'marydoe', password: 'password'}
]

app.get('/my-accounts', authenticate, (req, res) => {

    let accounts = [
        {accountNumber: '4567', balance: 4500}, 
        {accountNumber: '1234', balance: 5600}
    ]
    res.json(accounts)
})


// my-books is a protected resource, which means you need to send in the token 
// in order to get the books 
app.get('/my-books', authenticate, (req, res) => {

    const books = [
        {name: 'Atomic Habits'}, 
        {name: 'Ready Player One'}
    ]

    res.json(books)

})

app.post('/login', (req, res) => {

    const username = req.body.username 
    const password = req.body.password 

    const persistedUser = users.find(user => {
        return user.username == username && user.password == password 
    })

    if(persistedUser) {
        // generate the token 
         // DO NOT PUT SENSITIVE DATA INTO THE TOKEN 
        const token = jwt.sign({username: username}, process.env.JWT_SECRET_KEY)
        res.json({success: true, token: token})

    } else {
        res.json({success: false, message: 'User is not authenticated!'})
    }

})

app.listen(8080, () => {
    console.log('Server is running...')
})