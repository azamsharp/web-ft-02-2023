

function MyBooks(props) {

    const handleGetMyBooks = () => {

        const token = localStorage.getItem('jsonwebtoken')
       
        fetch('http://localhost:8080/my-books',{
            method: 'GET', 
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
        .then(response => response.json())
        .then(books => {
            console.log(books)
        })
    }

    return (
        <div>
            <button onClick = {handleGetMyBooks}>Get My Books</button>
        </div>
    )
}

export default MyBooks 