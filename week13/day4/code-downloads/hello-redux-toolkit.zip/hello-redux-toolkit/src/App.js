import './App.css';
import { useSelector, useDispatch } from 'react-redux';
import { useState } from 'react'
import { authActions, counterActions } from './store';

function App() {

  const [amount, setAmount] = useState(0)
  const counter = useSelector(state => state.ctr.counter)
  const isAuthenticated = useSelector(state => state.auth.isAuthenticated)

  const dispatch = useDispatch()

  const handleIncrement = () => {
    dispatch(counterActions.increment())
  }

  const handleDecrement = () => {
    dispatch(counterActions.decrement())
  }

  const handleIncrease = () => {
    dispatch(counterActions.increase(amount))
  }

  const handleChange = (e) => {
    const value = parseInt(e.target.value)
    setAmount(value)
  }

  const handleLogin = () => {
    dispatch(authActions.login())
  }

  const handleLogout = () => {
    dispatch(authActions.logout())
  }

  return (
    <>
      <h1>{counter}</h1>
      <input type = "text" onChange = {handleChange} />
      <button onClick = {handleIncrease}>Submit Increase</button>
      <button onClick = {handleIncrement}>Increment</button>
      <button onClick = {handleDecrement}>Decrement</button>
      <button onClick = {handleLogin}>Login</button>
      <button onClick = {handleLogout}>Logout</button>
      { isAuthenticated ? <h1>Authenticated</h1> : <h1>Not Authenticated</h1>}
    </>
  );
}

export default App;
