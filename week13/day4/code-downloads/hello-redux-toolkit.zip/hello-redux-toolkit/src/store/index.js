import { createSlice, configureStore } from "@reduxjs/toolkit"

const counterInitialState = {
    counter: 99, 
    showCounter: false 
}

const authenticationInitialState = {
    isAuthenticated: false 
}

const counterSlice = createSlice({
    name: 'counter', 
    initialState: counterInitialState, 
    reducers: {
        increment(state) {
            // new copy of the state and then updating the counter in that state 
            state.counter++
        }, 
        decrement(state) {
              // new copy of the state and then updating the counter in that state 
            state.counter--
        }, 
        increase(state, action) {
            // this action will increment the counter by the amount passed in as payload 
            state.counter = state.counter + action.payload
        }
    }
})

const authenticationSlice = createSlice({
    name: 'authentication', 
    initialState: authenticationInitialState, 
    reducers: {
        login(state) {
            state.isAuthenticated = true 
         }, 
        logout(state)  {
            state.isAuthenticated = false 
         }
    }
})

const store = configureStore({
    reducer: {
        ctr: counterSlice.reducer, 
        auth: authenticationSlice.reducer
    }
})

export const counterActions = counterSlice.actions
export const authActions = authenticationSlice.actions
export default store 