const express = require('express')
const app = express() 
const cors = require('cors')
const mongoose = require('mongoose')

const Book = require('./schemas/book')

app.use(cors())
app.use(express.json())

// Put password for MongoDB in the .env file, and also username
mongoose.connect('mongodb+srv://admin:Bbmg1rv4Jo23aPP7@cluster0.pjpecpj.mongodb.net/?retryWrites=true&w=majority', {
    useNewUrlParser: true
}, (error) => {
    if(!error) {
        console.log('Successfully connected to MongoDB Database')
    } else {
        console.log(error)
    }
})

// /api/books/1
// /api/books/639203b0f63b94e8ab802b18
app.get('/api/books/:bookId', (req, res) => {

    const bookId = req.params.bookId    

    Book.findById(bookId, (error, book) => {
        if(error) {
            res.json({success: false, message: `Unable to fetch book with id ${bookId}`})
        } else {
            res.json({success: true, book: book})
        }
    })

})


app.delete('/api/books/:bookId', (req, res) => {

    const bookId = req.params.bookId    
    Book.findByIdAndDelete(bookId, (error, book) => {
        if(error) {
            res.json({success: false, message: 'Unable to delete book.'})
        } else {
            res.json({success: true, book: book})
        }
    })
})

app.put('/api/books', (req, res) => {

    const bookId = req.body.bookId  
    const name = req.body.name 
    const isbn = req.body.isbn 
    const author = req.body.author 
    const isPublished = req.body.isPublished

    const updatedBook = {
        bookId: bookId, 
        name: name, 
        isbn: isbn, 
        author: author, 
        isPublished: isPublished 
    }

    Book.findByIdAndUpdate(bookId, updatedBook, (error, book) => {
        if(error) {
            res.json({success: false, message: 'Unable to update book.'})
        } else {
            res.json({success: true, book: book})
        }
    } )

}) 

app.get('/api/books', (req, res) => {

    Book.find({}, (error, books) => {
        if(error) {
            res.json({success: false, message: 'Unable to load all books.'})
        } else {
            res.json({success: true, books: books})
        }
    })

})

app.post('/api/books', (req, res) => {

    const name = req.body.name 
    const isbn = req.body.isbn 
    const author = req.body.author 
    const isPublished = req.body.isPublished

    // create an instance of Book model 
    const book = new Book({
        name: name, 
        isbn: isbn, 
        author: author, 
        isPublished: isPublished
    })

    // save the book to the datasbase 
    book.save((error) => {
        if(error) {
            res.json({success: false, message: error})
        } else {
            res.json({success: true, message: 'Book has been saved successfully.'})
        }
    })

})

app.listen(8080, () => {
    console.log('Server is running...')
})