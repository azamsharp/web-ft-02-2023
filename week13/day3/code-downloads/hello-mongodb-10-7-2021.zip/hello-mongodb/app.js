const express = require('express')
const app = express() 
const cors = require('cors')
const Student = require('./schemas/student')
const mongoose = require('mongoose')

app.use(cors())
app.use(express.json())

// mongodb+srv://dbUser:<password>@cluster0.5bnxr.mongodb.net/myFirstDatabase?retryWrites=true&w=majority

// username: newUser 
// password: XYYiSpDvj8fp8N9e
// database name: myFirstDatabase
mongoose.connect('mongodb+srv://newUser:XYYiSpDvj8fp8N9e@cluster0.5bnxr.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', {
    useNewUrlParser: true, useUnifiedTopology: true
}, (error) => {
    if(!error) {
        console.log('Successfully connected to MongoDB Database')
    } else {
        console.log(error)
    }
})

app.get('/students', (req, res) => {

    Student.find({}, (error, students) => {
        if(error) {
            res.json({success: false, message: 'Unable to get students'})
        } else {
            res.json(students)
        }
    })

})

app.get('/students/:studentId', (req, res) => {

    const studentId = req.params.studentId 
    
    Student.findById(studentId, ((error, student) => {
        if(error) {
            res.json({error: 'Unable to get student'})
        } else {
            res.json(student)
        }
    }))

})

app.post('/students', (req, res) => {

    const name = req.body.name 
    const location = req.body.location 
    const age = parseInt(req.body.age) 

    const student = new Student({
        name: name, 
        location: location, 
        age: age 
    })

    student.save((error) => {
        if(error) {
            res.json({success: false, message: error})
        } else {
            res.json({success: true, message: "Student has been saved"})
        }
    })

})

app.put('/students', (req, res) => {

    const studentId = req.body.studentId 
    const name = req.body.name 
    const location = req.body.location 
    const age = parseInt(req.body.age) 

    const updatedStudent = {
        name: name, 
        location: location, 
        age: age, 
        studentId: studentId
    }

    Student.findByIdAndUpdate(studentId, updatedStudent, (error, result) => {
        if(error) {
            res.json({error: 'Unable to updated'})
        } else {
            res.json({success: true})
        }
    })

})


app.listen(8080, () => {
    console.log('Server is running...')
})