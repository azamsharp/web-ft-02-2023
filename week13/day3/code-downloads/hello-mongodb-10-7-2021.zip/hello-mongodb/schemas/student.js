
const mongoose = require('mongoose')

const studentSchema = new mongoose.Schema({
    name: String, 
    location: String, 
    age: Number  
})

// mongoose.model('ModelName', schema) - Model Name automatically pluralize and becomes the collection name in the MongoDb database 
const Student = mongoose.model('Student', studentSchema)

module.exports = Student 