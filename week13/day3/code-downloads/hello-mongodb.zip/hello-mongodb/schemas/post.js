
const mongoose = require('mongoose')
const Comment = require('./comment')

const postSchema = new mongoose.Schema({
    title: String,
    body: String, 
    comments: [Comment.schema]
})

const Post = mongoose.model('Post', postSchema)

module.exports = Post 
