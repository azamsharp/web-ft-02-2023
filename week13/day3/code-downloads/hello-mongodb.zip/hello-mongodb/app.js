const express = require('express')
const app = express() 
const cors = require('cors')
const mongoose = require('mongoose')
const Post = require('./schemas/post')
const Comment = require('./schemas/comment')

app.use(cors())
app.use(express.json())

// connect to the mongodb database 
mongoose.connect('mongodb+srv://dbUser:dbUser@cluster0.5bnxr.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', {
    useNewUrlParser: true, useUnifiedTopology: true
}, (error) => {
    if(!error) {
        console.log('Successfully connected to MongoDB Database')
    } else {
        console.log(error)
    }
})

app.delete('/posts/:postId', (req, res) => {

    const postId = req.params.postId 

    Post.remove({
        _id: postId
    }, (error, result) => {
        if(error) {
            res.json({error: 'Unable to delete post'})
        } else {
            res.json({success: true, message: 'Post deleted successfully!'})
        }
    })

})


app.get('/posts/:postId', (req, res) => {

    const postId = req.params.postId 

    Post.findById(postId, ((error, post) => {
        if(error) {
            res.json({error: 'Unable to get post'})
        } else {
            res.json(post)
        }
    }))

})

app.get('/posts', (req, res) => {
    Post.find({}, (error, posts) => {
        if(error) {
            res.json({error: 'Unable to fetch posts!'}) 
        } else {
            res.json(posts)
        }
    })
})


app.post('/posts', (req, res) => {
    
    const title = req.body.title 
    const body = req.body.body 

    let post = new Post({
        title: title, 
        body: body 
    })

    post.save((error) => {
        if(error) {
            res.json({error: 'Unable the save!'})
        } else {
            res.json({success: true, message: 'Saved new post'})
        }
    })

})


app.put('/posts', (req, res) => {

    const postId = req.body.postId 
    const title = req.body.title 
    const body = req.body.body

    const updatedPost = {
        title: title, 
        postId: postId, 
        body: body 
    }

    Post.findByIdAndUpdate(postId, updatedPost, (error, result) => {
        if(error) {
            res.json({error: 'Unable to updated'})
        } else {
            res.json({success: true})
        }
    })

})



app.post('/comments', (req, res) => {

    const postId = req.body.postId 
    const subject = req.body.subject 
    const body = req.body.body 

    const comment = new Comment({
        subject: subject, 
        body: body 
    })

    // find the post by postId
    Post.findById(postId, (error, post) => {
        if(error) {
            res.json({error: 'Unable to find post'})
        } else {
            post.comments.push(comment)
            post.save(error => {
                if(error) {
                    res.json({error: 'Unable to save comment'})
                } else {
                    res.json({success: true, message: 'Comment has been saved!'})
                }
            })
        }
    })


})

app.listen(8080, () => {
    console.log('Server is running...')
})