
import { useEffect } from 'react'
import { useState } from 'react'
import axios from 'axios'
import { setAuthenticationHeader } from '../utils/authenticate'

function Dashboard(props) {

    const [accounts, setAccounts] = useState([])

    useEffect(() => {
        fetchAllAccounts()
    }, [])


    const fetchMyBooks = () => {
        
        axios.get('http://localhost:8080/my-books')
        .then(response => {
            console.log(response.data)
        })

    }

    const signOut = () => {
        // remove token from local storage 
        localStorage.removeItem("jsonwebtoken")
        localStorage.removeItem("username")

        // clear up the authentication headers 
        setAuthenticationHeader(null)
        // perform a dispatch and set the isAuthenticated global state to false 
        //props.onSignOut()
        
        props.history.push('/')
    }

    const fetchAllAccounts = () => {
        
        const username = localStorage.getItem('username')

        axios.get(`http://localhost:8080/accounts/${username}`)
        .then(response => {
            if(response.data.error) {
                console.log(response.data.error)
            } else {
                setAccounts(response.data)
            }
        })

        /*
        fetch(`http://localhost:8080/accounts/${username}`, {
            method: 'GET', 
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
        .then(response => response.json()) 
        .then(result => {
            setAccounts(result)
        }) */
    }


    
    const accountItems = accounts.map((account) => {
        return <div>{account.name} - {account.balance}</div>
    }) 

    return (
        <div>
            <h1>Dashboard</h1>
            {accountItems}
            <button onClick = {fetchMyBooks}>Get My Books</button>
            <button onClick = {signOut}>Sign Out</button>
        </div>
    )
}

export default Dashboard