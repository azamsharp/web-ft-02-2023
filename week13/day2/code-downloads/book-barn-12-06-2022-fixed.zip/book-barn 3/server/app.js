
const express = require('express')
const app = express()
const jwt = require('jsonwebtoken');
const cors = require('cors');
const authenticate = require('./middlewares/authMiddleware');

app.use(cors())
// body parser 
app.use(express.json())

global.users = [{ username: 'johndoe', password: 'password' }, { username: 'marydoe', password: 'password' }]
const books = [
    { name: 'Book 1', username: 'johndoe' },
    { name: 'Book 2', username: 'johndoe' },
    { name: 'Book 3', username: 'johndoe' },
    { name: 'Book 4', username: 'marydoe' }
]

app.get('/token', (req, res) => {
    const token = jwt.sign({}, 'SECRETKEYJWT')
    res.json({ token: token })
})

// /johndoe/books
// /marydoe/books 
// WE NEED TO PROTECT THIS ROUTE SO ONLY AUTHENTICATED USERS CAN ACCESS IT
// /api/johndoe/books
// /api/marydoe/books
// /api/steven/books
// /api/john/books
// /api/jerry/books
app.get('/api/:username/books', authenticate, (req, res) => {
    const username = req.params.username 
    const userBooks = books.filter(book => book.username == username)
    res.json(userBooks)
})

app.post('/add-book', authenticate, (req, res) => {
    const username = req.body.username
    req.send('ADD BOOK')
})

app.post('/api/login', (req, res) => {

    const username = req.body.username
    const password = req.body.password

    const savedUser = users.find(user => {
        return username == user.username && password == user.password
    })

    if (savedUser) {
        // create a json web token 
        // DO NOT PUT ANYTHING SENSITIVE IN THE TOKEN. THIS INCLUDES PASSWORD, SSN, CREDIT CARDS NUMBERS ETC 
        const token = jwt.sign({ username: savedUser.username }, 'SECRETKEYJWT')
        // return the response to the user with the token 
        res.json({ success: true, token: token, username: savedUser.username })
    } else {
        res.json({ success: false, message: 'Username or password is incorrect.' })
    }

})


app.listen(8080, () => {
    console.log('Server is running...')
})