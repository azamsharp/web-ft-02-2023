
import { useEffect } from 'react'
import { connect } from 'react-redux'
import { useNavigate } from 'react-router-dom'

function Signout(props) {

    const navigate = useNavigate()

    useEffect(() => {
        // remove the token from local storage 
        localStorage.removeItem('jwt')

        // remove the username from local storage 
        localStorage.removeItem('username')

        // update global redux state and set isAuthenticated to false 
        props.onSignout() 

        // take the user to Login 
        navigate('/')
    })

    return (
        <></>
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onSignout: () => dispatch({type: 'ON_SIGNOUT'})
    }
}

export default connect(null, mapDispatchToProps)(Signout)