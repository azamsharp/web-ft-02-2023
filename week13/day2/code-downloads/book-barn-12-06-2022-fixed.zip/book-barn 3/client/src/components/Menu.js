
import { connect } from 'react-redux'
import { NavLink } from 'react-router-dom'

function Menu(props) {
    return (
        <div>
           {props.isAuth ? null: <div>Login</div>}
           {props.isAuth ? null: <div>Register</div>}
            { props.isAuth ? <NavLink to = "/books">Books</NavLink>: null  }
            { props.isAuth ? <NavLink to = "/signout">Signout</NavLink>: null  }
        </div>
    )
}

const mapStateToProps = (state) => {
    return {
        isAuth: state.isAuthenticated 
    }
}

export default connect(mapStateToProps)(Menu)