import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Login from './components/Login';
import BookList from './components/BookList';
import BaseLayout from './components/BaseLayout';
import { Provider } from 'react-redux'
import { createStore } from 'redux'
import reducer from './store/reducer';
import Signout from './components/Signout';
import ProtectedRoute from './components/ProtectedRoute';

const store = createStore(reducer, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__())

// get the token 
const token = localStorage.getItem('jwt')
if(token) {
  // dispatch an action to update the isAuthenticated property in global state 
  store.dispatch({type: 'ON_LOGIN', payload: token})
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Provider store = {store}>
    <BrowserRouter>
    <BaseLayout>
      <Routes>
        <Route path = "/" element = { <Login />} />
        <Route path = "/books" element = { <ProtectedRoute><BookList /></ProtectedRoute>} /> 
        <Route path = "/signout" element = { <Signout />} />
      </Routes>
    </BaseLayout>
    </BrowserRouter>
    </Provider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
