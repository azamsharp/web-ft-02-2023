import { Component } from "react";
import { connect } from 'react-redux'
import { useNavigate } from "react-router-dom";


export default function(ComposedComponent) {

    class Authenticate extends Component {

        constructor(props) {
            super(props)

            if(!this.props.isAuth) {
                // if the person is not authenticated 
                this.props.history.push('/')
            }
        }

        render() {
            return <ComposedComponent {...this.props} />
        }
    }

    const mapStateToProps = (state) => {
        return {
            isAuth: state.isAuthenticated 
        }
    }

    return connect(mapStateToProps)(Authenticate)

}