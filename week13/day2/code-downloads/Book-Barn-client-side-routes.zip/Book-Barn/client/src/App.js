import Login from "./components/Login";
import MyAccounts from "./components/MyAccounts";
import MyBooks from "./components/MyBooks";


function App() {
  return (
    <div>
    <Login />
    <MyBooks />
    <MyAccounts />
    </div>

  );
}

export default App;
