
import { useEffect } from 'react'
import { connect } from 'react-redux'

function Signout(props) {

    useEffect(() => {

        // remove the token from local storage 
        localStorage.removeItem('jsonwebtoken')

        // update the global state isAuthenticated = false 
        props.onLogout() 
        
        // take the user back to login page after signout 
        props.history.push('/')

    })

    return (
        <h1>You are signed out!</h1>
    )

}

const mapDispatchToProps = (dispatch) => {
    return {
        onLogout: () => dispatch({type: 'ON_LOGOUT'})
    }
}

export default connect(null, mapDispatchToProps)(Signout)