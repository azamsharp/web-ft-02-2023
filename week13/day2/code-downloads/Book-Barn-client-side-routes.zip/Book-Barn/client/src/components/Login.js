
import { useState } from 'react'
import { connect } from 'react-redux'

function Login(props) {

    const [user, setUser] = useState({})

    const handleOnChange = (e) => {
        setUser({
            ...user,
            [e.target.name]: e.target.value 
        })
    }

    const handleLogin = () => {

        fetch('http://localhost:8080/login', {
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json'
            }, 
            body: JSON.stringify(user)
        }).then(response => response.json())
        .then(result => {

            // save token in local storage 
            localStorage.setItem('jsonwebtoken', result.token) 
            // update global store isAuthenticated to true 
            props.onLogin()
            console.log(result)
        })

    }

    return (
        <div>
            <h1>Login</h1>
            <input name = "username" onChange = {handleOnChange} type = "text" placeholder = "Username" />
            <input name = "password" onChange = {handleOnChange} type = "text" placeholder = "Password"/>
            <button onClick = {handleLogin}>Login</button>
            
        </div>
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onLogin: () => dispatch({type: 'ON_LOGIN'})
    }
}

export default connect(null,mapDispatchToProps)(Login)