

// requireAuth is a higher order component 
// you are going to pass another component to requireAuth component 
// and requireAuth component is going to decide whether the passed in component 
// gets rendered or not 

import { Component } from "react";
import { connect } from 'react-redux'

export default function(ComposedComponent) {

    class Authenticate extends Component {

        constructor(props) {

            super(props)

            if(!this.props.isAuthenticated) { // user is not authenticated 
                // redirect to login page 
                this.props.history.push('/')
            }

        }

        render() {
            return <ComposedComponent {...this.props} />
        }

    }

    const mapStateToProps = (state) => {
        return {
            isAuthenticated: state.isAuthenticated 
        }
    }

    return connect(mapStateToProps)(Authenticate)

}