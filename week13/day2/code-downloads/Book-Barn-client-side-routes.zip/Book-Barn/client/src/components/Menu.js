import { NavLink } from "react-router-dom"
import './Menu.css'
import { connect } from 'react-redux'


function Menu(props) {

    return (
        <div id = "menu">
            <NavLink to = "/">Login</NavLink>

            {props.isAuth ?  <NavLink to = "/my-books">My Books</NavLink> : null }
            {props.isAuth ?  <NavLink to = "/my-accounts">My Accounts</NavLink> : null }
            {props.isAuth ?  <NavLink to = "/sign-out">Signout</NavLink> : null }
           
        </div>
    )

}

const mapStateToProps = (state) => {
    return {
        isAuth: state.isAuthenticated 
    }
}

export default connect(mapStateToProps)(Menu)