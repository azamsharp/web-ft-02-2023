

function MyAccounts(props) {

    const handleGetMyAccounts = () => {

        const token = localStorage.getItem('jsonwebtoken')

        fetch('http://localhost:8080/my-accounts', {
            method: 'GET', 
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
        .then(response => response.json())
        .then(accounts => {
            console.log(accounts)
        })

    }

    return (
        <div>
            <button onClick = {handleGetMyAccounts}>Get My Accounts</button>
        </div>
    )

}

export default MyAccounts 