
import { useEffect, useState } from 'react'

function MyBooks(props) {

    const [books, setBooks] = useState([])

    useEffect(() => {
        fetchAllBooks()
    }, [])

    const fetchAllBooks = () => {

        const token = localStorage.getItem('jsonwebtoken')

        fetch('http://localhost:8080/my-books', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(books => {
                setBooks(books)
            })
    }

    const bookItems = books.map(book => {
        return <li key = {book.isbn}>{book.name}</li>
    })

    return (
        <div>
            {bookItems}
        </div>
    )
}

export default MyBooks