
from calculator import Calculator 

input("Welcome to Calculator")

print("1. Add: ")
print("2. Subtract: ")

choice = input("Enter choice: ")

if choice == 1: 
    result = calculator.add(1,2)

