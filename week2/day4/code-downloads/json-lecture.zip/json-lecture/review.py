
from datetime import datetime 

pool_tables = [] 

class PoolTable:
    def __init__(self, number):
        self.number = number
        self.is_occupied = False
        self.start_time = None
        self.end_time = None

    def check_in(): 
        pass 

    def check_out(self): 
        self.is_occupied = True 
        self.start_time = datetime.now() 
        self.save_to_file()
        
    def save_to_file(self): 
        with open("pool_tables.txt", "w") as file:
            file.write(str(self.number)) 
            # convert date to string
            file.write("07/15/2021 9:45 AM")

# create 12 pool tables and put them in the array 
for i in range(1,13):
    pool_table = PoolTable(i)
    pool_tables.append(pool_table)



while True: 
    print("1. Checkout Pool Table: ")
    print("2. CheckIn Pool Table: ")
    print("3. View Pool Tables: ")
    print("q. Quit: ")

    choice = input("Enter choice: ")
    if choice == "q": 
        break 
    
    if choice == "1": 
        # display all tables 
        for table in pool_tables: 
            print(f"Table #{table.number}")
            print(f"CheckOut Time {table.start_time}")

        # which table they want to check out 
        table_number = int(input("Enter table number to check-out: "))

        # access table using table_number 
        table = pool_tables[table_number - 1]
        # check out table 
        table.check_out() 
        #table.check_in() # ERROR