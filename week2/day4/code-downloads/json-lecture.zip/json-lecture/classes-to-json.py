
import json 

class PoolTable: 
    def __init__(self, table_number):
        self.table_number = table_number 


def dictionary_to_pool_table(dict): 
    return PoolTable(dict["table_number"]) 


pt = PoolTable(6)
print(pt.__dict__) 

with open("pool_tables.json", "w") as file: 
    json.dump(pt.__dict__, file)

with open("pool_tables.json") as file: 
    pool_table_dict = json.load(file)

pool_table = dictionary_to_pool_table(pool_table_dict)
#pool_table.check_in()