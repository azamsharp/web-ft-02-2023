
class Calculator: 
    def __init__(self): 
        pass 
    
    def add(self, a, b): 
        return a+b
    