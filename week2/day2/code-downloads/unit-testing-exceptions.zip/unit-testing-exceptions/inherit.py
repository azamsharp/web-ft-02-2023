
# INHERITENCE 

class Car: 
    def __init__(self, make, model): 
        self.make = make 
        self.model = model 
    
    def drive(self): 
        print("DRIVE")
    
    def fill_up(self): 
        print("FILL UP GAS")


# ElectricCar inherits from the Car class 
# Parent class, Car is called the super class 
# ElectricClass is called sub class 
class ElectricCar(Car): 
    def __init__(self, make, model): 
        # always make sure to call the super class constructor in the subclass 
        super().__init__(make, model)

    def fill_up(self): 
        print("START CHARGING....")


electric_car = ElectricCar("Tesla", "Model X") 
print(electric_car.make)
print(electric_car.model)
print(electric_car.drive())

electric_car.fill_up() 