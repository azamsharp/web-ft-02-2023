
try: 
    result = 1/0
    number = float(input("Enter number: ")) 
    #database.open()
    # do something with database 
    #database.close() 
# zero division exception block 
except ZeroDivisionError: 
    print("Divided by ZERO!")
except ValueError: 
    print("Please input only numbers!")
except: 
    print("Opps something bad happened!")
 # optional block. Fired when no exceptions are thrown 
else: 
    print("ELSE BLOCK")
# optional 
# finally block is fired no matter what. This means it fired when the exception happens or does not happen 
# finally is used to clean up the resources 
# close database connections, file connections, socket connections 
finally: 
    print("FINALLY")
    #database.close() 
