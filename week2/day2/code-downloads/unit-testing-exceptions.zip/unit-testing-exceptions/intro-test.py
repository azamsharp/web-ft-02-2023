# TEST DRIVEN DEVELOPMENT
# 1. Write a failing test 
# 2. Make the test pass 
# 3. Refactor 
# 4. Repeat 

# UNIT TEST RULES 
# 1. Unit Test should be independent
# 2. Unit Test should NEVER wait for human input 
# 3. Unit Tests should be repeatable 

import unittest # import unit test framework 
# from bank_account file import BankAccount class 
from bank_account import BankAccount

# import all classes, functions from the bank_account file 
# from bank_account import *  

from calculator import Calculator 
# from file factorial import function factorial 
from factorial import factorial 

class FactoritalTests(unittest.TestCase): 

    def test_should_return_zero_for_negative_numbers(self): 
        result = factorial(-1)
        #self.assertTrue(1 == 1)
        self.assertEqual(0, result)


    def test_should_calculate_correct_factorial(self): 
        result = factorial(5)
        self.assertEqual(120, result)

class CalculatorTests(unittest.TestCase): 

    def test_add(self): 
        calculator = Calculator() 
        result = calculator.add(2,7)
        self.assertEqual(9, result)


class BankAccountTests(unittest.TestCase): 

    # setup is called before each test is run 
    def setUp(self): 
        print("SETUP")
        self.bank_account = BankAccount(500)

    def test_deposit_money_in_bank(self): 
        print("test_deposit_money_in_bank")
        self.bank_account.deposit(100)
        self.assertEqual(600, self.bank_account.balance)

    def test_withdraw_money_from_bank_with_insufficient_balance(self): 
        pass 

    def test_withdraw_money_from_bank(self): 
        print("test_withdraw_money_from_bank")
        self.bank_account.withdraw(300)
        self.assertEqual(200, self.bank_account.balance)

    def test_transfer_funds_between_accounts(self):
        print("test_transfer_funds_between_accounts") 
        destination_account = BankAccount(100)
        self.bank_account.transfer(400, destination_account)

        self.assertEqual(100, self.bank_account.balance)
        self.assertEqual(500, destination_account.balance)

unittest.main() # this is to run the test 