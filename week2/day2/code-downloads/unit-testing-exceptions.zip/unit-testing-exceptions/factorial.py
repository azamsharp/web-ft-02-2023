
def factorial(no): 

    if no < 0: 
        return 0 

    result = 1 
    for index in range(1, no + 1): 
        result *= index 
    return result 
