

class Calculator: 
    def __init__(self): 
        pass 
    
    def add(a,b): 
        return a+b 

