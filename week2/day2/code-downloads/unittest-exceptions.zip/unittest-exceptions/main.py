

from calculator import Calculator

a = int(input("Enter first number: "))