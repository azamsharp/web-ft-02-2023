# If we list all the natural numbers below 30 that are multiples of 7 or 11, we get 7, 11, 14 and 21 and 28. The sum of these multiples is 81.

# Using python write figure out how you could find and return the sum of all the multiples of 7 or 11 below 1000.

def theSum 