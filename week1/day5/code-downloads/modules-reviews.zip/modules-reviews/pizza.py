

def create_pizza(size, toppings):
    print(f"Creating pizza of size {size} with toppings {toppings}")

def deliver_pizza(address): 
    print(f"Deliver pizza to {address}")