

def is_palindrome(word): 
    pass 

def is_even(number): 
    pass 


deif is_prime(number): 
    pass 